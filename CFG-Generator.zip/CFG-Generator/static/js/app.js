/* CFG Studio - application wiring. Every piece of user/server text is inserted with textContent (never innerHTML). */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var state = { result: null, source: '', exampleId: null, examples: [], busy: false };

  function el(tag, opts, children) {
    var n = document.createElement(tag);
    opts = opts || {};
    if (opts.cls) n.className = opts.cls;
    if (opts.text !== undefined) n.textContent = opts.text;
    if (opts.attrs) Object.keys(opts.attrs).forEach(function (k) { n.setAttribute(k, opts.attrs[k]); });
    (children || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  function clearNode(n) { while (n.firstChild) n.removeChild(n.firstChild); }

  /* ---------------------------------------------------------------- status / messages */
  var messages = [];
  function setStatus(t) { $('status').textContent = 'Status: ' + t; }
  function renderMessages() {
    var ul = $('messages');
    clearNode(ul);
    messages.forEach(function (m) {
      var sev = { error: 'Error', warning: 'Warning', success: 'Success', info: 'Info' }[m.severity];
      var li = el('li', { cls: m.severity }, [el('span', { cls: 'sev', text: sev }), el('span', { text: m.text })]);
      if (m.line) {
        var b = el('button', { cls: 'link-btn where', text: 'line ' + m.line + (m.col ? ', col ' + m.col : ''), attrs: { type: 'button' } });
        b.addEventListener('click', function () { CFGEditor.focusLine(m.line, m.col); });
        li.appendChild(b);
      }
      ul.appendChild(li);
    });
    $('msg-count').textContent = String(messages.length);
  }
  function setMessages(list) { messages = list; renderMessages(); }

  /* ---------------------------------------------------------------- dashboard */
  function setMetrics(m) {
    var dash = function (v) { return v === null || v === undefined ? '\u2014' : String(v); };
    $('m-blocks').textContent = dash(m && m.basicBlocks);
    $('m-decisions').textContent = dash(m && m.decisionNodes);
    $('m-nodes').textContent = dash(m && m.cfgNodes);
    $('m-edges').textContent = dash(m && m.cfgEdges);
    $('m-loops').textContent = dash(m && m.loopBackEdges);
    $('m-unreach').textContent = dash(m && m.unreachableNodes);
    $('m-cc').textContent = dash(m && m.cyclomaticComplexity);
    if (!m) {
      $('m-cc-sub').textContent = 'E \u2212 N + 2P';
      $('convention-text').textContent = 'Generate a CFG to see the exact conventions used for this program.';
      $('convention-note').textContent = '';
      return;
    }
    $('m-cc-sub').textContent = m.conventionsAgree ? 'decisions+1 = ' + m.cyclomaticPredicateBased + ' \u2713'
      : 'decisions+1 = ' + m.cyclomaticPredicateBased + ' (differs)';
    $('convention-text').textContent = m.convention + ' Reachable nodes: ' + m.reachableNodes + ' of ' + m.cfgNodes + '.';
    $('convention-note').textContent = m.conventionNote + ' Loop back edges are edges into a node that dominates their source.';
  }

  /* ---------------------------------------------------------------- inspector */
  function nodeById(id) { return state.result.graph.nodes.filter(function (n) { return n.id === id; })[0]; }
  function edgeById(id) { return state.result.graph.edges.filter(function (e) { return e.id === id; })[0]; }
  function nodeLink(id) {
    var b = el('button', { cls: 'link-btn', text: id, attrs: { type: 'button' } });
    b.addEventListener('click', function () { CFGGraph.selectNode(id); showNode(id); });
    return b;
  }
  function edgeLink(id) {
    var b = el('button', { cls: 'link-btn', text: id, attrs: { type: 'button' } });
    b.addEventListener('click', function () { CFGGraph.selectEdge(id); showEdge(id); });
    return b;
  }
  function labelSpan(e) {
    var cls = e.label === 'True' ? 't' : e.label === 'False' ? 'f' : e.isBack ? 'b' : '';
    return el('span', { cls: 'lbl ' + cls, text: e.label ? e.label : 'unconditional' });
  }
  function kv(pairs) {
    var dl = el('dl', { cls: 'kv' });
    pairs.forEach(function (p) {
      dl.appendChild(el('dt', { text: p[0] }));
      var dd = el('dd');
      if (typeof p[1] === 'string') dd.textContent = p[1]; else dd.appendChild(p[1]);
      dl.appendChild(dd);
    });
    return dl;
  }
  function linesText(lines) {
    if (!lines.length) return 'none';
    return lines.length > 1 && lines[lines.length - 1] - lines[0] === lines.length - 1 ? lines[0] + '\u2013' + lines[lines.length - 1] : lines.join(', ');
  }
  var KIND_TEXT = { entry: 'Synthetic entry edge', sequential: 'Sequential flow (falls through to the next block)', jump: 'Unconditional jump',
                    true: 'Branch taken when the condition is true', false: 'Branch taken when the condition is false', return: 'Return: leaves main' };

  function showNode(id) {
    var n = nodeById(id), d = $('details');
    clearNode(d);
    var head = el('div', {}, [el('span', { cls: 'badge-type ' + n.type, text: n.type === 'decision' ? 'Decision' : n.type === 'block' ? 'Basic block' : n.type.toUpperCase() })]);
    if (!n.reachable) head.appendChild(el('span', { cls: 'badge-type dead', text: ' unreachable ' }));
    d.appendChild(head);
    d.appendChild(kv([['Node ID', n.id], ['Node type', n.type], ['Reachable', n.reachable ? 'yes' : 'no \u2014 no path from ENTRY'],
      ['Source lines', linesText(n.lines)], ['Ends with', { fallthrough: 'fall-through', branch: 'conditional branch', jump: 'jump', return: 'return', none: 'nothing (terminal)' }[n.terminator]]]));
    if (n.type === 'entry' || n.type === 'exit') d.appendChild(el('p', { cls: 'muted', text: n.note + ' - it holds no source code.' }));
    if (n.type === 'block' || n.type === 'decision') {
      var title = el('div', { cls: 'sec-title', text: 'Statements in this block' });
      var ul = el('ul', { cls: 'code-list' });
      n.statements.forEach(function (s) { ul.appendChild(el('li', {}, [el('span', { cls: 'ln-no', text: String(s.line) }), el('span', { text: s.text })])); });
      if (n.condition) ul.appendChild(el('li', {}, [el('span', { cls: 'ln-no', text: String(n.condition.line) }), el('span', { cls: 'cond', text: 'branch on: ' + n.condition.text })]));
      if (!n.statements.length && !n.condition) ul.appendChild(el('li', {}, [el('span', { cls: 'ln-no', text: '\u2014' }), el('span', { cls: 'muted', text: '(no statements)' })]));
      d.appendChild(el('div', {}, [title, ul]));
      if (n.note) d.appendChild(el('p', { cls: 'muted', text: n.note }));
    }
    [['Incoming edges', function (e) { return e.target === id; }, 'source'], ['Outgoing edges', function (e) { return e.source === id; }, 'target']].forEach(function (spec) {
      var list = state.result.graph.edges.filter(spec[1]);
      var ul = el('ul', { cls: 'edge-list' });
      list.forEach(function (e) {
        var other = spec[2] === 'source' ? e.source : e.target;
        var tail = [el('span', { text: ' ' }), labelSpan(e), el('span', { text: ' (edge ' }), edgeLink(e.id), el('span', { text: e.isBack ? ', loop back edge)' : ')' })];
        var head = spec[2] === 'source' ? [nodeLink(other), el('span', { text: ' \u2192 this' })] : [el('span', { text: 'this \u2192 ' }), nodeLink(other)];
        var li = el('li', {}, head.concat(tail));
        ul.appendChild(li);
      });
      if (!list.length) ul.appendChild(el('li', { cls: 'muted', text: 'none' }));
      d.appendChild(el('div', {}, [el('div', { cls: 'sec-title', text: spec[0] + ' (' + list.length + ')' }), ul]));
    });
    CFGEditor.highlight(n.lines);
  }

  function showEdge(id) {
    var e = edgeById(id), d = $('details'), src = nodeById(e.source);
    clearNode(d);
    d.appendChild(el('div', {}, [el('span', { cls: 'badge-type ' + (e.label === 'True' || e.label === 'False' ? 'decision' : 'block'), text: 'Edge ' + e.id })]));
    var rows = [['Edge ID', e.id], ['Source', nodeLink(e.source)], ['Target', nodeLink(e.target)],
      ['Branch label', e.label || 'none (unconditional)'], ['Meaning', KIND_TEXT[e.kind] || e.kind],
      ['Loop back edge', e.isBack ? 'yes \u2014 target dominates source' : 'no']];
    if (src.condition && (e.label === 'True' || e.label === 'False')) rows.push(['Taken when', src.condition.text + ' is ' + e.label.toLowerCase()]);
    if (!e.reachable) rows.push(['Reachable', 'no \u2014 source is unreachable']);
    d.appendChild(kv(rows));
    CFGEditor.highlight(src.lines);
  }

  function showInspectorEmpty() {
    var d = $('details'); clearNode(d);
    d.appendChild(el('p', { cls: 'muted', text: 'Click a node or an edge in the graph to inspect it. Click the node again, or the empty canvas, to clear the selection.' }));
    var dl = el('dl', { cls: 'concepts' });
    [['Basic block', 'Straight-line code with one entry (its first statement) and one exit (its last).'],
     ['Decision', 'A block that ends in a condition. It has exactly one True and one False edge.'],
     ['Back edge', 'An edge into a node that dominates its source: it closes a loop.']].forEach(function (p) {
      dl.appendChild(el('dt', { text: p[0] })); dl.appendChild(el('dd', { text: p[1] }));
    });
    d.appendChild(dl);
    CFGEditor.highlight([]);
  }

  /* ---------------------------------------------------------------- IR / validation panes */
  function renderIR(analysis) {
    var pane = $('pane-ir'); clearNode(pane);
    pane.appendChild(el('p', { cls: 'muted', text: 'Structured IR after lowering. A bold index with a blue rule is a leader (start of a basic block). Jump-only compiler-generated rows are merged away after block formation.' }));
    var table = el('table', { cls: 'ir' });
    table.appendChild(el('thead', {}, [el('tr', {}, ['#', 'Instruction', 'Line', 'Block'].map(function (h) { return el('th', { text: h }); }))]));
    var tb = el('tbody');
    analysis.ir.forEach(function (r) {
      var tr = el('tr', { cls: (r.isLeader ? 'leader ' : '') + (r.block ? '' : 'merged') });
      tr.appendChild(el('td', { text: (r.isLeader ? '\u2691 ' : '') + r.index }));
      tr.appendChild(el('td', { text: r.text }));
      tr.appendChild(el('td', { text: r.line ? String(r.line) : '' }));
      var td = el('td');
      if (r.block) { var b = el('button', { cls: 'link-btn', text: r.block, attrs: { type: 'button' } }); b.addEventListener('click', function () { CFGGraph.selectNode(r.block); showNode(r.block); }); td.appendChild(b); }
      else td.textContent = 'merged';
      tr.appendChild(td); tb.appendChild(tr);
    });
    if (!analysis.ir.length) { var tr0 = el('tr'); var td0 = el('td', { text: '(empty program: no instructions)' }); td0.setAttribute('colspan', '4'); tr0.appendChild(td0); tb.appendChild(tr0); }
    table.appendChild(tb); pane.appendChild(table);
  }
  function renderValidation(analysis) {
    var pane = $('pane-validation'); clearNode(pane);
    var v = analysis.validation;
    pane.appendChild(el('p', { text: (v.passed ? 'All ' + v.checks.length + ' structural checks passed.' : 'Some checks failed.') + ' Only the checks listed below were run.' }));
    var ul = el('ul', { cls: 'checks' });
    v.checks.forEach(function (c) { ul.appendChild(el('li', {}, [el('span', { cls: c.passed ? 'ok' : 'bad', text: c.passed ? 'PASS' : 'FAIL' }), el('span', { text: c.name + (c.passed ? '' : ' \u2014 ' + c.detail) })])); });
    pane.appendChild(ul);
    pane.appendChild(el('p', { cls: 'muted', text: 'Pipeline stages run: ' + analysis.stages.join(' \u2192 ') + '.' }));
  }
  function clearPanes() {
    var ir = $('pane-ir'); clearNode(ir); ir.appendChild(el('p', { cls: 'muted', text: 'Generate a CFG to see the IR and the leaders.' }));
    var v = $('pane-validation'); clearNode(v); v.appendChild(el('p', { cls: 'muted', text: 'Generate a CFG to see the validation report.' }));
  }

  function selectTab(name) {
    ['messages', 'ir', 'validation'].forEach(function (t) {
      var on = t === name;
      $('tab-' + t).classList.toggle('active', on); $('tab-' + t).setAttribute('aria-selected', String(on));
      $('pane-' + t).classList.toggle('active', on); $('pane-' + t).hidden = !on;
    });
  }

  /* ---------------------------------------------------------------- graph panel states */
  function showOverlay(which) {
    ['graph-empty', 'graph-loading', 'graph-error'].forEach(function (id) { $(id).hidden = id !== which; });
  }
  function setExports(enabled) {
    ['export-png', 'export-svg', 'export-json'].forEach(function (id) { $(id).disabled = !enabled; $(id).title = enabled ? '' : 'Generate a CFG first'; });
  }
  function setBusy(b) {
    state.busy = b;
    $('generate-btn').disabled = b;
    $('generate-btn').textContent = b ? 'Analysing...' : 'Generate CFG';
    if (b) { showOverlay('graph-loading'); setStatus('analysing...'); }
  }

  function showError(err) {
    CFGGraph.clearGraph(); state.result = null; setExports(false); setMetrics(null); clearPanes(); showInspectorEmpty();
    var cat = { syntax: 'Syntax error', lexical: 'Lexical error', unsupported: 'Unsupported construct', semantic: 'Semantic error', limit: 'Input too large', input: 'Invalid input', internal: 'Internal error' }[err.category] || 'Error';
    var where = err.line ? ' (line ' + err.line + (err.column ? ', column ' + err.column : '') + ')' : '';
    $('graph-error-title').textContent = cat + where;
    $('graph-error-text').textContent = err.error + (err.hint ? '\n' + err.hint : '');
    showOverlay('graph-error');
    CFGEditor.clearMarks();
    if (err.line) CFGEditor.markError(err.line);
    setMessages([{ severity: 'error', text: cat + ': ' + err.error + (err.hint ? ' ' + err.hint : ''), line: err.line, col: err.column }]);
    selectTab('messages');
    setStatus('failed (' + (err.category || 'error') + ')');
  }

  function showResult(res, source) {
    state.result = res; state.source = source;
    showOverlay(null);
    CFGGraph.load(res.graph);
    setMetrics(res.metrics); renderIR(res.analysis); renderValidation(res.analysis); showInspectorEmpty(); setExports(true);
    var m = res.metrics;
    var list = [{ severity: 'success', text: 'CFG generated: ' + m.basicBlocks + ' basic blocks, ' + m.decisionNodes + ' decision node(s), ' + m.cfgEdges + ' edges, cyclomatic complexity ' + m.cyclomaticComplexity + '.' }];
    res.warnings.forEach(function (w) { list.push({ severity: 'warning', text: w.message, line: w.line }); });
    if (!res.warnings.length) list.push({ severity: 'info', text: 'No warnings. Structural validation: ' + (res.analysis.validation.passed ? 'all checks passed.' : 'FAILED.') });
    setMessages(list);
    CFGEditor.clearMarks();
    CFGEditor.markWarnings(res.warnings.map(function (w) { return w.line; }));
    setStatus('CFG ready');
  }

  /* ---------------------------------------------------------------- generate */
  function generate() {
    if (state.busy) return;
    var code = CFGEditor.getCode();
    if (!code.trim()) { showError({ category: 'input', error: 'The editor is empty. Pick an example or type a program such as: int main() { ... }' }); return; }
    if (code.length > CFGEditor.max()) { showError({ category: 'limit', error: 'Input is too long (' + code.length + ' characters). Limit: ' + CFGEditor.max() + '.' }); return; }
    setBusy(true);
    var ctl = new AbortController(), timer = setTimeout(function () { ctl.abort(); }, 15000);
    return fetch('/api/generate-cfg', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: code }), signal: ctl.signal })
      .then(function (r) { return r.json().catch(function () { return null; }); })
      .then(function (body) {
        if (!body || typeof body.success !== 'boolean') throw new Error('The server sent an unreadable response.');
        if (body.success) showResult(body, code); else showError(body);
      })
      .catch(function (e) {
        var msg = e && e.name === 'AbortError' ? 'The request timed out.' : (e && e.message && e.message.indexOf('Malformed graph') === 0 ? e.message : 'Could not reach the CFG Studio server. Is run.bat (or python app.py) still running?');
        showError({ category: 'internal', error: msg });
      })
      .then(function () { clearTimeout(timer); setBusy(false); });
  }

  /* ---------------------------------------------------------------- examples */
  function loadExample(id) {
    var ex = state.examples.filter(function (e) { return e.id === id; })[0];
    if (!ex) { state.exampleId = null; $('example-info').hidden = true; $('reset-btn').disabled = true; $('reset-btn').title = 'Load an example first'; return; }
    state.exampleId = id;
    CFGEditor.setCode(ex.code);
    $('ex-name').textContent = ex.name; $('ex-expected').textContent = ex.expected; $('ex-explain').textContent = ex.explanation;
    $('example-info').hidden = false; $('reset-btn').disabled = false; $('reset-btn').title = 'Restore the code of the selected example';
    generate();
  }

  /* ---------------------------------------------------------------- export */
  function stamp() { return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19); }
  function doExport(kind) {
    try {
      if (!state.result) throw new Error('Generate a CFG first.');
      if (kind === 'png') { CFGGraph.download(CFGGraph.exportPNG(), 'cfg-graph.png'); }
      else if (kind === 'svg') {
        var url = URL.createObjectURL(new Blob([CFGGraph.exportSVG()], { type: 'image/svg+xml' }));
        CFGGraph.download(url, 'cfg-graph.svg'); setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
      } else {
        var r = state.result;
        var data = { tool: 'CFG Studio', exportedAt: new Date().toISOString(), source: state.source, graph: r.graph, metrics: r.metrics, warnings: r.warnings, analysis: r.analysis };
        var u2 = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
        CFGGraph.download(u2, 'cfg-data.json'); setTimeout(function () { URL.revokeObjectURL(u2); }, 2000);
      }
      setStatus('exported ' + kind.toUpperCase());
      messages = messages.concat([{ severity: 'info', text: 'Exported ' + kind.toUpperCase() + ' (' + stamp() + ').' }]); renderMessages();
    } catch (e) {
      messages = messages.concat([{ severity: 'error', text: 'Export ' + kind.toUpperCase() + ' failed: ' + (e && e.message ? e.message : 'unknown error') }]); renderMessages();
      setStatus('export failed'); selectTab('messages');
    }
  }

  /* ---------------------------------------------------------------- theme / fullscreen */
  function applyThemeUI() {
    var dark = document.documentElement.getAttribute('data-theme') === 'dark';
    $('theme-btn').textContent = dark ? 'Light theme' : 'Dark theme';
    $('theme-btn').setAttribute('aria-label', dark ? 'Switch to light theme' : 'Switch to dark theme');
  }
  function toggleTheme() {
    var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('cfgstudio-theme', next); } catch (e) { /* ignore */ }
    applyThemeUI(); CFGGraph.applyTheme();
  }
  function toggleFullscreen() {
    var card = $('graph-card');
    var fs = document.fullscreenElement === card || card.classList.contains('pseudo-fs');
    function after() { setTimeout(function () { CFGGraph.resize(); CFGGraph.fit(); }, 120); }
    if (fs) {
      if (document.fullscreenElement) document.exitFullscreen(); card.classList.remove('pseudo-fs'); $('fullscreen-btn').textContent = 'Fullscreen'; after();
    } else if (card.requestFullscreen) {
      card.requestFullscreen().then(function () { $('fullscreen-btn').textContent = 'Exit fullscreen'; after(); })
        .catch(function () { card.classList.add('pseudo-fs'); $('fullscreen-btn').textContent = 'Exit fullscreen'; after(); });
    } else { card.classList.add('pseudo-fs'); $('fullscreen-btn').textContent = 'Exit fullscreen'; after(); }
  }

  /* ---------------------------------------------------------------- init */
  function init() {
    applyThemeUI();
    CFGEditor.init(function () { /* typing clears stale marks only */ });
    try {
      CFGGraph.init($('cy'), {
        onNode: function (id) { showNode(id); }, onEdge: function (id) { showEdge(id); }, onClear: function () { showInspectorEmpty(); }
      });
    } catch (e) {
      setMessages([{ severity: 'error', text: 'The graph library could not start: ' + e.message }]);
    }
    clearPanes(); setExports(false); setMetrics(null);
    setMessages([{ severity: 'info', text: 'Ready. Choose an example or write a program, then press Generate CFG.' }]);

    $('generate-btn').addEventListener('click', generate);
    $('clear-btn').addEventListener('click', function () {
      CFGEditor.setCode(''); CFGEditor.focus(); CFGGraph.clearGraph(); state.result = null; setExports(false); setMetrics(null); clearPanes(); showInspectorEmpty();
      showOverlay('graph-empty'); setMessages([{ severity: 'info', text: 'Editor cleared.' }]); setStatus('idle');
    });
    $('reset-btn').addEventListener('click', function () { if (state.exampleId) loadExample(state.exampleId); });
    $('code').addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); generate(); } });
    $('example-select').addEventListener('change', function (e) { loadExample(e.target.value); });
    $('theme-btn').addEventListener('click', toggleTheme);
    $('help-btn').addEventListener('click', function () { var d = $('help-dialog'); if (d.showModal) d.showModal(); else d.setAttribute('open', ''); });
    $('zoom-in').addEventListener('click', function () { CFGGraph.zoom(1.25); });
    $('zoom-out').addEventListener('click', function () { CFGGraph.zoom(0.8); });
    $('fit-btn').addEventListener('click', function () { CFGGraph.fit(); });
    $('relayout-btn').addEventListener('click', function () { CFGGraph.relayout(); });
    $('layout-select').addEventListener('change', function (e) { CFGGraph.setLayout(e.target.value); });
    $('fullscreen-btn').addEventListener('click', toggleFullscreen);
    document.addEventListener('fullscreenchange', function () {
      if (!document.fullscreenElement) $('fullscreen-btn').textContent = 'Fullscreen';
      setTimeout(function () { CFGGraph.resize(); CFGGraph.fit(); }, 120);
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && $('graph-card').classList.contains('pseudo-fs')) toggleFullscreen(); });
    ['messages', 'ir', 'validation'].forEach(function (t) { $('tab-' + t).addEventListener('click', function () { selectTab(t); }); });
    $('export-png').addEventListener('click', function () { doExport('png'); });
    $('export-svg').addEventListener('click', function () { doExport('svg'); });
    $('export-json').addEventListener('click', function () { doExport('json'); });
    if (window.ResizeObserver) new ResizeObserver(function () { CFGGraph.resize(); }).observe($('cy'));

    fetch('/api/examples').then(function (r) { return r.json(); }).then(function (body) {
      state.examples = body.examples || [];
      var sel = $('example-select');
      state.examples.forEach(function (ex) { sel.appendChild(el('option', { text: ex.name, attrs: { value: ex.id } })); });
    }).catch(function () {
      setMessages(messages.concat([{ severity: 'warning', text: 'Could not load the example list from the server.' }]));
    });
  }
  document.addEventListener('DOMContentLoaded', init);
})();
