/* Graph view: Cytoscape.js rendering, selection highlighting, layout and PNG/SVG export. */
(function () {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg';
  var FONT = 12, LINE_H = 16;
  var cy = null, graph = null, cb = {}, layoutName = 'TB', selected = null;
  var measureCtx = document.createElement('canvas').getContext('2d');
  // Cytoscape's unbundled-bezier: a positive distance moves the control point to this side of source->target.
  // (Verified in a headless-browser test: the control point is offset by d * (-vy, vx) / |v|.)
  function normalOf(vx, vy) { var l = Math.hypot(vx, vy) || 1; return { x: -vy / l, y: vx / l }; }

  function css(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }
  function mono() { return css('--font-mono'); }
  function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + '\u2026' : s; }

  function labelLines(n) {
    if (n.type === 'entry') return ['ENTRY'];
    if (n.type === 'exit') return ['EXIT'];
    var lines = [];
    if (n.type === 'decision') {
      lines.push(n.id + ': ' + truncate(n.condition.text, 28) + ' ?');
      if (n.statements.length) lines.push('(+' + n.statements.length + (n.statements.length > 1 ? ' stmts)' : ' stmt)'));
      return lines;
    }
    lines.push(n.id);
    if (!n.statements.length) { lines.push('(no statements)'); return lines; }
    n.statements.slice(0, 6).forEach(function (s) { lines.push(truncate(s.text, 34)); });
    if (n.statements.length > 6) lines.push('\u2026 +' + (n.statements.length - 6) + ' more');
    return lines;
  }

  function textWidth(lines) {
    measureCtx.font = FONT + 'px ' + mono();
    var w = 0;
    lines.forEach(function (l) { w = Math.max(w, measureCtx.measureText(l).width); });
    return w;
  }

  function nodeBox(n, lines) {
    var tw = textWidth(lines), th = lines.length * LINE_H;
    if (n.type === 'entry' || n.type === 'exit') return { w: Math.max(96, tw + 40), h: 38, tw: tw, th: th };
    if (n.type === 'decision') return { w: Math.max(120, 1.9 * tw + 36), h: 1.7 * th + 22, tw: tw, th: th };
    return { w: Math.max(80, tw + 30), h: th + 20, tw: tw, th: th };
  }

  function buildStyle() {
    var text = css('--g-text'), edge = css('--g-edge'), canvas = css('--canvas');
    return [
      { selector: 'node', style: {
        'shape': 'round-rectangle', 'width': 'data(w)', 'height': 'data(h)', 'label': 'data(label)',
        'text-wrap': 'wrap', 'text-valign': 'center', 'text-halign': 'center', 'text-justification': 'left',
        'font-family': mono(), 'font-size': FONT, 'line-height': LINE_H / FONT, 'color': text,
        'background-color': css('--g-block-bg'), 'border-width': 1.6, 'border-color': css('--g-block-bd') } },
      { selector: 'node.entry', style: { 'shape': 'ellipse', 'background-color': css('--g-entry-bg'), 'border-color': css('--g-entry-bd') } },
      { selector: 'node.exit', style: { 'shape': 'ellipse', 'background-color': css('--g-exit-bg'), 'border-color': css('--g-exit-bd') } },
      { selector: 'node.decision', style: { 'shape': 'diamond', 'background-color': css('--g-dec-bg'), 'border-color': css('--g-dec-bd') } },
      { selector: 'node.dead', style: { 'border-style': 'dashed', 'background-color': css('--g-dead-bg'), 'border-color': css('--g-dead-bd'), 'color': edge } },
      { selector: 'edge', style: {
        'width': 1.9, 'line-color': edge, 'target-arrow-color': edge, 'target-arrow-shape': 'triangle', 'arrow-scale': 1.15,
        'curve-style': 'bezier', 'label': 'data(label)', 'font-size': 11, 'font-family': mono(), 'color': edge,
        'text-background-color': canvas, 'text-background-opacity': 0.92, 'text-background-padding': 2,
        'text-background-shape': 'roundrectangle', 'text-rotation': 'none', 'loop-direction': '-45deg', 'loop-sweep': '-30deg' } },
      { selector: 'edge.true', style: { 'line-color': css('--g-true'), 'target-arrow-color': css('--g-true'), 'color': css('--g-true'), 'font-weight': 'bold' } },
      { selector: 'edge.false', style: { 'line-color': css('--g-false'), 'target-arrow-color': css('--g-false'), 'color': css('--g-false'), 'font-weight': 'bold' } },
      { selector: 'edge.back', style: { 'line-style': 'dashed', 'line-dash-pattern': [7, 4], 'width': 2.4 } },
      { selector: 'edge.back.plain', style: { 'line-color': css('--g-back'), 'target-arrow-color': css('--g-back'), 'color': css('--g-back') } },
      { selector: 'edge.dead', style: { 'line-style': 'dotted', 'opacity': 0.7 } },
      { selector: '.faded', style: { 'opacity': 0.28 } },
      { selector: 'edge.in', style: { 'line-color': css('--g-in'), 'target-arrow-color': css('--g-in'), 'width': 3.4, 'color': css('--g-in'), 'z-index': 9 } },
      { selector: 'edge.out', style: { 'line-color': css('--g-out'), 'target-arrow-color': css('--g-out'), 'width': 3.4, 'color': css('--g-out'), 'z-index': 9 } },
      { selector: 'node.sel', style: { 'border-width': 3.4, 'border-color': css('--g-sel') } },
      { selector: 'edge.sel', style: { 'line-color': css('--g-sel'), 'target-arrow-color': css('--g-sel'), 'width': 4, 'color': css('--g-sel'), 'z-index': 10 } }
    ];
  }

  function layoutOptions() {
    if (layoutName === 'breadthfirst' || typeof cytoscape('layout', 'dagre') === 'undefined') {
      return { name: 'breadthfirst', directed: true, roots: '#ENTRY', spacingFactor: 1.15, padding: 36, animate: false };
    }
    return { name: 'dagre', rankDir: layoutName, nodeSep: 44, rankSep: 46, edgeSep: 24, padding: 28,
             nodeDimensionsIncludeLabels: false, animate: false, fit: true };
  }

  // Curved routing: back edges bow out to the side of the loop; parallel edges are fanned apart.
  function routeEdges() {
    var pref = layoutName === 'LR' ? { x: 0, y: 1 } : { x: 1, y: 0 };
    cy.edges().forEach(function (e) {
      e.scratch('cd', 0);
      if (e.isLoop()) return;
      var s = e.source().position(), t = e.target().position();
      var d = 0;
      var group = e.parallelEdges();
      if (group.length > 1) d = (group.indexOf(e) - (group.length - 1) / 2) * 52;
      if (e.hasClass('back')) {
        var minY = Math.min(s.y, t.y), maxY = Math.max(s.y, t.y), minX = Math.min(s.x, t.x), maxX = Math.max(s.x, t.x), half = 0;
        cy.nodes().forEach(function (n) {
          var p = n.position();
          var inside = layoutName === 'LR' ? (p.x >= minX - 1 && p.x <= maxX + 1) : (p.y >= minY - 1 && p.y <= maxY + 1);
          if (inside) half = Math.max(half, layoutName === 'LR' ? n.data('h') / 2 : n.data('w') / 2);
        });
        var nrm = normalOf(t.x - s.x, t.y - s.y), mid = { x: (s.x + t.x) / 2, y: (s.y + t.y) / 2 };
        var plus = 0, minus = 0;   // how many other nodes sit on each side of the straight source->target line
        cy.nodes().forEach(function (n) {
          if (n.id() === e.source().id() || n.id() === e.target().id()) return;
          var p = n.position();
          var inside = layoutName === 'LR' ? (p.x >= minX && p.x <= maxX) : (p.y >= minY && p.y <= maxY);
          if (!inside) return;
          if ((p.x - mid.x) * nrm.x + (p.y - mid.y) * nrm.y > 0) plus++; else minus++;
        });
        var sign = plus === minus ? ((nrm.x * pref.x + nrm.y * pref.y) >= 0 ? 1 : -1) : (plus < minus ? 1 : -1);
        d = sign * 2 * (half + 46);                       // apex of a quadratic curve sits at d / 2
      }
      e.scratch('cd', d);
      if (d !== 0) e.style({ 'curve-style': 'unbundled-bezier', 'control-point-distances': [d], 'control-point-weights': [0.5] });
      else e.removeStyle('curve-style control-point-distances control-point-weights');
    });
  }

  function fitView() {
    cy.fit(undefined, 28);
    if (cy.zoom() > 1.15) { cy.zoom(1.15); cy.center(); }   // small graphs are not blown up
  }

  function runLayout(fit) {
    if (!cy) return;
    var l = cy.layout(layoutOptions());
    l.one('layoutstop', function () { routeEdges(); if (fit !== false) fitView(); });
    l.run();
  }

  function clearClasses() { cy.elements().removeClass('faded sel in out'); }

  function select(kind, id) {
    clearClasses();
    selected = { kind: kind, id: id };
    var ele = cy.getElementById(id);
    if (!ele.length) return;
    cy.elements().addClass('faded');
    ele.removeClass('faded').addClass('sel');
    if (kind === 'node') {
      ele.incomers('edge').removeClass('faded').addClass('in');
      ele.outgoers('edge').removeClass('faded').addClass('out');
      ele.neighborhood('node').removeClass('faded');
    } else {
      ele.source().removeClass('faded'); ele.target().removeClass('faded');
    }
  }

  function clear() { if (cy) clearClasses(); selected = null; }

  function validate(g) {
    var idRe = /^[A-Za-z0-9_]{1,32}$/, types = { entry: 1, exit: 1, block: 1, decision: 1 };
    if (!g || !Array.isArray(g.nodes) || !Array.isArray(g.edges)) return 'graph.nodes and graph.edges must be arrays';
    var ids = {};
    for (var i = 0; i < g.nodes.length; i++) {
      var n = g.nodes[i];
      if (!n || typeof n.id !== 'string' || !idRe.test(n.id) || ids[n.id]) return 'invalid or duplicate node id';
      if (!types[n.type]) return 'unknown node type';
      if (!Array.isArray(n.statements) || !Array.isArray(n.lines)) return 'malformed node data';
      if (n.type === 'decision' && (!n.condition || typeof n.condition.text !== 'string')) return 'decision without condition';
      ids[n.id] = true;
    }
    var eids = {};
    for (var j = 0; j < g.edges.length; j++) {
      var e = g.edges[j];
      if (!e || typeof e.id !== 'string' || !idRe.test(e.id) || eids[e.id] || ids[e.id]) return 'invalid or duplicate edge id';
      if (!ids[e.source] || !ids[e.target]) return 'edge endpoint is not a node';
      if (typeof e.label !== 'string') return 'malformed edge label';
      eids[e.id] = true;
    }
    return null;
  }

  function toElements(g) {
    var els = [];
    g.nodes.forEach(function (n) {
      var lines = labelLines(n), box = nodeBox(n, lines);
      els.push({ group: 'nodes', data: { id: n.id, label: lines.join('\n'), w: box.w, h: box.h, tw: box.tw, th: box.th, lines: lines },
                 classes: n.type + (n.reachable ? '' : ' dead') });
    });
    g.edges.forEach(function (e) {
      var cls = [];
      if (e.label === 'True') cls.push('true'); else if (e.label === 'False') cls.push('false'); else if (e.isBack) cls.push('plain');
      if (e.isBack) cls.push('back');
      if (!e.reachable) cls.push('dead');
      els.push({ group: 'edges', data: { id: e.id, source: e.source, target: e.target, label: e.label },
                 classes: cls.join(' ') });
    });
    return els;
  }

  function download(href, name) {
    var a = document.createElement('a'); a.href = href; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  }

  function svgEl(name, attrs, text) {
    var el = document.createElementNS(NS, name);
    Object.keys(attrs || {}).forEach(function (k) { el.setAttribute(k, String(attrs[k])); });
    if (text !== undefined) el.textContent = text;
    return el;
  }
  function fmt(v) { return Math.round(v * 100) / 100; }

  window.CFGGraph = {
    init: function (container, callbacks) {
      cb = callbacks || {};
      if (typeof cytoscape === 'undefined') throw new Error('Cytoscape.js failed to load');
      try { if (window.cytoscapeDagre && typeof cytoscape('layout', 'dagre') === 'undefined') cytoscape.use(window.cytoscapeDagre); } catch (e) { /* already registered */ }
      cy = cytoscape({ container: container, elements: [], style: buildStyle(), minZoom: 0.1, maxZoom: 3,
                       boxSelectionEnabled: false, autounselectify: true });
      cy.on('tap', 'node', function (evt) {
        var id = evt.target.id();
        if (selected && selected.kind === 'node' && selected.id === id) { clear(); if (cb.onClear) cb.onClear(); return; }
        select('node', id); if (cb.onNode) cb.onNode(id);
      });
      cy.on('tap', 'edge', function (evt) { var id = evt.target.id(); select('edge', id); if (cb.onEdge) cb.onEdge(id); });
      cy.on('tap', function (evt) { if (evt.target === cy) { clear(); if (cb.onClear) cb.onClear(); } });
    },
    load: function (g) {
      var problem = validate(g);
      if (problem) throw new Error('Malformed graph data: ' + problem);
      graph = g; selected = null;
      cy.batch(function () { cy.elements().remove(); cy.add(toElements(g)); });
      cy.style(buildStyle());
      runLayout(true);
    },
    clearGraph: function () { if (cy) { cy.elements().remove(); } graph = null; selected = null; },
    hasGraph: function () { return !!graph; },
    selectNode: function (id) { select('node', id); },
    selectEdge: function (id) { select('edge', id); },
    clearSelection: clear,
    setLayout: function (name) { layoutName = name; runLayout(true); },
    relayout: function () { runLayout(true); },
    fit: function () { if (cy) fitView(); },
    zoom: function (factor) { if (!cy) return; cy.zoom({ level: cy.zoom() * factor, renderedPosition: { x: cy.width() / 2, y: cy.height() / 2 } }); },
    resize: function () { if (cy) cy.resize(); },
    applyTheme: function () { if (!cy) return; cy.style(buildStyle()); if (graph) { cy.edges().forEach(function (e) { var d = e.scratch('cd'); if (d) e.style({ 'curve-style': 'unbundled-bezier', 'control-point-distances': [d], 'control-point-weights': [0.5] }); }); } },
    debug: function () { return cy; },

    exportPNG: function () {
      if (!cy || !graph) throw new Error('No graph to export');
      return cy.png({ full: true, scale: 2, bg: css('--canvas') });
    },

    exportSVG: function () {
      if (!cy || !graph) throw new Error('No graph to export');
      var c = {
        canvas: css('--canvas'), text: css('--g-text'), edge: css('--g-edge'), t: css('--g-true'), f: css('--g-false'), back: css('--g-back'),
        blockBg: css('--g-block-bg'), blockBd: css('--g-block-bd'), decBg: css('--g-dec-bg'), decBd: css('--g-dec-bd'),
        entryBg: css('--g-entry-bg'), entryBd: css('--g-entry-bd'), exitBg: css('--g-exit-bg'), exitBd: css('--g-exit-bd'),
        deadBg: css('--g-dead-bg'), deadBd: css('--g-dead-bd')
      };
      var font = mono();
      var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      function grow(x, y) { minX = Math.min(minX, x); minY = Math.min(minY, y); maxX = Math.max(maxX, x); maxY = Math.max(maxY, y); }
      var edgeShapes = [];
      cy.nodes().forEach(function (n) { var p = n.position(), w = n.data('w'), h = n.data('h'); grow(p.x - w / 2, p.y - h / 2); grow(p.x + w / 2, p.y + h / 2); });
      cy.edges().forEach(function (e) {
        var s = e.source(), t = e.target(), sp = s.position(), tp = t.position(), d = e.scratch('cd') || 0, shape;
        if (e.isLoop()) {
          var x = sp.x + s.data('w') / 2, y = sp.y;
          shape = { path: 'M ' + fmt(x) + ' ' + fmt(y - 7) + ' C ' + fmt(x + 58) + ' ' + fmt(y - 44) + ' ' + fmt(x + 58) + ' ' + fmt(y + 44) + ' ' + fmt(x) + ' ' + fmt(y + 7),
                    lx: x + 46, ly: y, pts: [[x + 46, y - 30], [x + 46, y + 30]] };
        } else {
          var a = e.sourceEndpoint ? e.sourceEndpoint() : sp, b = e.targetEndpoint ? e.targetEndpoint() : tp;
          if (!isFinite(a.x) || !isFinite(b.x)) { a = sp; b = tp; }
          if (d === 0) {
            shape = { path: 'M ' + fmt(a.x) + ' ' + fmt(a.y) + ' L ' + fmt(b.x) + ' ' + fmt(b.y), lx: (a.x + b.x) / 2, ly: (a.y + b.y) / 2, pts: [[a.x, a.y], [b.x, b.y]] };
          } else {
            var nrm = normalOf(tp.x - sp.x, tp.y - sp.y);
            var cx = (sp.x + tp.x) / 2 + nrm.x * d, cyy = (sp.y + tp.y) / 2 + nrm.y * d;
            shape = { path: 'M ' + fmt(a.x) + ' ' + fmt(a.y) + ' Q ' + fmt(cx) + ' ' + fmt(cyy) + ' ' + fmt(b.x) + ' ' + fmt(b.y),
                      lx: (a.x + 2 * cx + b.x) / 4, ly: (a.y + 2 * cyy + b.y) / 4, pts: [[a.x, a.y], [cx, cyy], [b.x, b.y]] };
          }
        }
        shape.pts.forEach(function (p) { grow(p[0], p[1]); });
        edgeShapes.push({ e: e, shape: shape });
      });
      var pad = 36, W = Math.ceil(maxX - minX + 2 * pad), H = Math.ceil(maxY - minY + 2 * pad);
      var ox = pad - minX, oy = pad - minY;
      var svg = svgEl('svg', { xmlns: NS, width: W, height: H, viewBox: '0 0 ' + W + ' ' + H, 'font-family': font });
      svg.appendChild(svgEl('title', {}, 'Control flow graph - CFG Studio'));
      var defs = svgEl('defs');
      [['edge', c.edge], ['true', c.t], ['false', c.f], ['back', c.back]].forEach(function (m) {
        var mk = svgEl('marker', { id: 'arrow-' + m[0], viewBox: '0 0 10 10', refX: 9, refY: 5, markerWidth: 9, markerHeight: 9, markerUnits: 'userSpaceOnUse', orient: 'auto' });
        mk.appendChild(svgEl('path', { d: 'M0,0 L10,5 L0,10 z', fill: m[1] }));
        defs.appendChild(mk);
      });
      svg.appendChild(defs);
      svg.appendChild(svgEl('rect', { x: 0, y: 0, width: W, height: H, fill: c.canvas }));
      var g = svgEl('g', { transform: 'translate(' + fmt(ox) + ' ' + fmt(oy) + ')' });
      svg.appendChild(g);
      edgeShapes.forEach(function (it) {
        var e = it.e, k = e.hasClass('true') ? 'true' : e.hasClass('false') ? 'false' : e.hasClass('back') ? 'back' : 'edge';
        var col = { edge: c.edge, true: c.t, false: c.f, back: c.back }[k];
        var attrs = { d: it.shape.path, fill: 'none', stroke: col, 'stroke-width': e.hasClass('back') ? 2.4 : 1.9, 'marker-end': 'url(#arrow-' + k + ')' };
        if (e.hasClass('back')) attrs['stroke-dasharray'] = '7 4'; else if (e.hasClass('dead')) attrs['stroke-dasharray'] = '2 4';
        g.appendChild(svgEl('path', attrs));
      });
      cy.nodes().forEach(function (n) {
        var p = n.position(), w = n.data('w'), h = n.data('h'), type = n.hasClass('entry') ? 'entry' : n.hasClass('exit') ? 'exit' : n.hasClass('decision') ? 'decision' : 'block';
        var dead = n.hasClass('dead');
        var fill = dead ? c.deadBg : { entry: c.entryBg, exit: c.exitBg, decision: c.decBg, block: c.blockBg }[type];
        var stroke = dead ? c.deadBd : { entry: c.entryBd, exit: c.exitBd, decision: c.decBd, block: c.blockBd }[type];
        var common = { fill: fill, stroke: stroke, 'stroke-width': 1.6 };
        if (dead) common['stroke-dasharray'] = '5 3';
        if (type === 'entry' || type === 'exit') g.appendChild(svgEl('ellipse', Object.assign({ cx: fmt(p.x), cy: fmt(p.y), rx: fmt(w / 2), ry: fmt(h / 2) }, common)));
        else if (type === 'decision') g.appendChild(svgEl('polygon', Object.assign({ points: [[p.x, p.y - h / 2], [p.x + w / 2, p.y], [p.x, p.y + h / 2], [p.x - w / 2, p.y]].map(function (q) { return fmt(q[0]) + ',' + fmt(q[1]); }).join(' ') }, common)));
        else g.appendChild(svgEl('rect', Object.assign({ x: fmt(p.x - w / 2), y: fmt(p.y - h / 2), width: fmt(w), height: fmt(h), rx: 8 }, common)));
        var lines = n.data('lines'), tw = n.data('tw'), top = p.y - (lines.length * LINE_H) / 2;
        lines.forEach(function (ln, i) {
          g.appendChild(svgEl('text', { x: fmt(p.x - tw / 2), y: fmt(top + i * LINE_H + LINE_H * 0.74), 'font-size': FONT, fill: dead ? c.edge : c.text, 'xml:space': 'preserve' }, ln));
        });
      });
      edgeShapes.forEach(function (it) {
        var label = it.e.data('label');
        if (!label) return;
        var k = it.e.hasClass('true') ? c.t : it.e.hasClass('false') ? c.f : it.e.hasClass('back') ? c.back : c.edge;
        measureCtx.font = '11px ' + font;
        var w = measureCtx.measureText(label).width + 6;
        g.appendChild(svgEl('rect', { x: fmt(it.shape.lx - w / 2), y: fmt(it.shape.ly - 8), width: fmt(w), height: 16, rx: 3, fill: c.canvas, 'fill-opacity': 0.92 }));
        g.appendChild(svgEl('text', { x: fmt(it.shape.lx), y: fmt(it.shape.ly + 4), 'font-size': 11, 'text-anchor': 'middle', fill: k, 'font-weight': it.e.hasClass('true') || it.e.hasClass('false') ? 'bold' : 'normal' }, label));
      });
      return '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(svg);
    },
    download: download
  };
})();
