/* Source editor: textarea + synchronised line-number gutter. All text is set via textContent. */
(function () {
  'use strict';
  var ta, gutter, counter, max = 20000, changeCb = null;
  var errLine = null, warnLines = new Set(), hlLines = new Set();

  function lineCount() { return ta.value.split('\n').length; }

  function renderGutter() {
    var n = lineCount();
    gutter.textContent = '';
    for (var i = 1; i <= n; i++) {
      var d = document.createElement('div');
      d.textContent = String(i);
      if (hlLines.has(i)) d.classList.add('hl');
      if (warnLines.has(i)) d.classList.add('warn');
      if (errLine === i) d.classList.add('err');
      gutter.appendChild(d);
    }
    var spacer = document.createElement('div');
    spacer.style.height = '48px';
    gutter.appendChild(spacer);
    gutter.scrollTop = ta.scrollTop;
  }

  function renderCount() {
    var chars = ta.value.length;
    counter.textContent = 'Lines: ' + lineCount() + ' \u00b7 Characters: ' + chars + ' / ' + max;
    counter.classList.toggle('over', chars > max);
  }

  function refresh() { renderGutter(); renderCount(); }

  window.CFGEditor = {
    init: function (onChange) {
      ta = document.getElementById('code');
      gutter = document.getElementById('gutter');
      counter = document.getElementById('count');
      max = parseInt(ta.getAttribute('data-max'), 10) || max;
      changeCb = onChange;
      ta.addEventListener('input', function () {
        errLine = null; warnLines.clear(); hlLines.clear();
        refresh();
        if (changeCb) changeCb();
      });
      ta.addEventListener('scroll', function () { gutter.scrollTop = ta.scrollTop; });
      refresh();
    },
    max: function () { return max; },
    getCode: function () { return ta.value; },
    setCode: function (text) { ta.value = text; errLine = null; warnLines.clear(); hlLines.clear(); refresh(); },
    clearMarks: function () { errLine = null; warnLines.clear(); hlLines.clear(); renderGutter(); },
    markError: function (line) { errLine = line || null; renderGutter(); if (line) this.reveal(line); },
    markWarnings: function (lines) { warnLines = new Set((lines || []).filter(Boolean)); renderGutter(); },
    highlight: function (lines) { hlLines = new Set((lines || []).filter(Boolean)); renderGutter(); },
    reveal: function (line) {
      var top = (line - 1) * 20;
      if (top < ta.scrollTop || top > ta.scrollTop + ta.clientHeight - 60) ta.scrollTop = Math.max(0, top - 60);
      gutter.scrollTop = ta.scrollTop;
    },
    focusLine: function (line, col) {
      var lines = ta.value.split('\n'), start = 0;
      for (var i = 0; i < line - 1 && i < lines.length; i++) start += lines[i].length + 1;
      var end = start + (lines[line - 1] ? lines[line - 1].length : 0);
      ta.focus();
      var caret = Math.min(start + Math.max(0, (col || 1) - 1), end);
      ta.setSelectionRange(caret, end);
      this.reveal(line);
    },
    focus: function () { ta.focus(); }
  };
})();
