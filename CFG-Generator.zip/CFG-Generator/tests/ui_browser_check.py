"""Optional real-browser check of CFG Studio (needs requirements-dev.txt and a running server).

Usage:  python app.py   (in one terminal)
        python tests/ui_browser_check.py   (in another)
The browser logs deliberate 400 responses (invalid-input tests); those are filtered out.
"""
import json, re, xml.dom.minidom, base64, struct, tempfile, os, sys
from playwright.sync_api import sync_playwright

BASE = os.environ.get("CFG_URL", "http://127.0.0.1:5000/")
SHOTS = tempfile.mkdtemp(prefix="cfg_shots_")
results = []
def ok(name, cond, extra=""):
    results.append((name, bool(cond), extra)); print(("PASS " if cond else "FAIL ") + name, extra)

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 1500, "height": 950}, accept_downloads=True)
    pg = ctx.new_page()
    errs = []
    pg.on("console", lambda m: errs.append(m.text) if m.type in ("error", "warning") and "400" not in m.text else None)
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(BASE)
    pg.wait_for_selector("#example-select option:nth-child(5)", state="attached")
    ok("empty state visible before generation", pg.is_visible("#graph-empty"))
    ok("export buttons disabled before generation", pg.is_disabled("#export-png") and pg.is_disabled("#export-svg") and pg.is_disabled("#export-json"))

    def click_node(nid):
        box = pg.locator("#cy").bounding_box()
        rp = pg.evaluate("(id) => { const n = CFGGraph.debug().getElementById(id); const p = n.renderedPosition(); return {x:p.x,y:p.y}; }", nid)
        pg.mouse.click(box["x"] + rp["x"], box["y"] + rp["y"])
        pg.wait_for_timeout(250)
    def click_edge(eid):
        box = pg.locator("#cy").bounding_box()
        rp = pg.evaluate("(id) => { const e = CFGGraph.debug().getElementById(id); const p = e.renderedMidpoint(); return {x:p.x,y:p.y}; }", eid)
        pg.mouse.click(box["x"] + rp["x"], box["y"] + rp["y"])
        pg.wait_for_timeout(250)

    # --- loop example
    pg.select_option("#example-select", "loop-if"); pg.wait_for_timeout(1000)
    ok("metrics shown", pg.inner_text("#m-blocks") == "6" and pg.inner_text("#m-cc") == "3")
    n = pg.evaluate("() => { const c = CFGGraph.debug(); return {n: c.nodes().length, e: c.edges().length, back: c.edges('.back').length}; }")
    ok("graph rendered in Cytoscape", n == {"n": 8, "e": 9, "back": 1}, str(n))
    click_node("B2")
    txt = pg.inner_text("#details")
    ok("node click shows inspector (id, statements, edges)", "B2" in txt and "i < 10" in txt and "Incoming edges (2)" in txt and "Outgoing edges (2)" in txt, txt[:80].replace("\n"," "))
    cls = pg.evaluate("() => { const c = CFGGraph.debug(); return {sel: c.nodes('.sel').map(x=>x.id()), in: c.edges('.in').length, out: c.edges('.out').length}; }")
    ok("node selected; incoming and outgoing edges highlighted", cls == {"sel": ["B2"], "in": 2, "out": 2}, str(cls))
    ok("source lines highlighted in editor gutter", pg.locator("#gutter .hl").count() >= 1)
    click_node("B2")
    ok("clicking selected node again clears selection", pg.evaluate("() => CFGGraph.debug().elements('.sel').length") == 0)
    eid = pg.evaluate("() => CFGGraph.debug().edges('.back')[0].id()")
    click_edge(eid)
    txt = pg.inner_text("#details")
    ok("edge click shows source/target/label", "Edge " + eid in txt and "Loop back edge" in txt and "yes" in txt, txt[:100].replace("\n", " "))
    ok("edge highlighted", pg.evaluate("(id) => CFGGraph.debug().getElementById(id).hasClass('sel')", eid))
    box = pg.locator("#cy").bounding_box()
    pg.mouse.click(box["x"] + 12, box["y"] + 12); pg.wait_for_timeout(200)
    ok("clicking empty canvas clears selection", pg.evaluate("() => CFGGraph.debug().elements('.sel').length") == 0)

    # --- zoom/fit/layout
    z0 = pg.evaluate("() => CFGGraph.debug().zoom()")
    pg.click("#zoom-in"); z1 = pg.evaluate("() => CFGGraph.debug().zoom()")
    pg.click("#zoom-out"); pg.click("#zoom-out"); z2 = pg.evaluate("() => CFGGraph.debug().zoom()")
    ok("zoom in / out change zoom", z1 > z0 > z2, f"{z0:.2f} {z1:.2f} {z2:.2f}")
    pg.click("#fit-btn"); z3 = pg.evaluate("() => CFGGraph.debug().zoom()")
    ok("fit restores overall view", abs(z3 - z0) < 0.01, f"{z3:.2f}")
    pg.select_option("#layout-select", "LR"); pg.wait_for_timeout(500)
    pos = pg.evaluate("() => { const c=CFGGraph.debug(); return [c.getElementById('ENTRY').position().x, c.getElementById('EXIT').position().x]; }")
    ok("left-to-right layout puts EXIT right of ENTRY", pos[1] > pos[0], str(pos))
    pg.select_option("#layout-select", "breadthfirst"); pg.wait_for_timeout(500)
    ok("breadth-first layout works", pg.evaluate("() => CFGGraph.debug().nodes().length") == 8)
    pg.select_option("#layout-select", "TB"); pg.click("#relayout-btn"); pg.wait_for_timeout(500)

    # --- IR / validation tabs
    pg.click("#tab-ir"); t = pg.inner_text("#pane-ir")
    ok("IR tab lists leaders", "\u2691" in t and "goto" in t)
    pg.click("#tab-validation"); t = pg.inner_text("#pane-validation")
    ok("validation tab lists passed checks", "PASS" in t and "FAIL" not in t)
    pg.click("#tab-messages")

    # --- exports
    with pg.expect_download() as d: pg.click("#export-png")
    path = d.value.path(); data = open(path, "rb").read()
    w, h = struct.unpack(">II", data[16:24])
    ok("PNG export is a real PNG with size", data[:8] == b"\x89PNG\r\n\x1a\n" and w > 200 and h > 200, f"{w}x{h} {len(data)} bytes")
    with pg.expect_download() as d: pg.click("#export-svg")
    svg = open(d.value.path(), encoding="utf-8").read()
    doc = xml.dom.minidom.parseString(svg)
    ok("SVG export is well-formed XML", doc.documentElement.tagName == "svg")
    ok("SVG contains all nodes' text, paths for edges", svg.count("<path") >= 9 + 4 and "i % 2 == 0" in svg and "back edge" in svg and svg.count("<polygon") == 2, f"paths={svg.count('<path')} polygons={svg.count('<polygon')}")
    open(SHOTS + "/export.svg", "w").write(svg)
    with pg.expect_download() as d: pg.click("#export-json")
    j = json.load(open(d.value.path(), encoding="utf-8"))
    ok("JSON export has source, graph, metrics", j["tool"] == "CFG Studio" and "evens++" in j["source"] and len(j["graph"]["nodes"]) == 8 and j["metrics"]["cyclomaticComplexity"] == 3)

    # --- theme
    pg.click("#theme-btn"); pg.wait_for_timeout(400)
    ok("dark theme applied", pg.evaluate("() => document.documentElement.dataset.theme") == "dark")
    pg.screenshot(path=SHOTS + "/dark.png")
    with pg.expect_download() as d: pg.click("#export-svg")
    ok("SVG export follows theme", "#111820" in open(d.value.path(), encoding="utf-8").read())
    pg.reload(); pg.wait_for_timeout(500)
    ok("theme persisted across reload", pg.evaluate("() => document.documentElement.dataset.theme") == "dark")
    pg.click("#theme-btn")

    # --- error handling
    pg.select_option("#example-select", "invalid"); pg.wait_for_timeout(900)
    ok("error overlay shown with position", pg.is_visible("#graph-error") and "line 2" in pg.inner_text("#graph-error-title"), pg.inner_text("#graph-error-title"))
    ok("error line marked in gutter", pg.locator("#gutter .err").count() == 1)
    ok("exports disabled after error; metrics reset", pg.is_disabled("#export-png") and pg.inner_text("#m-blocks") == "\u2014")
    ok("message links to the source line", "line 2" in pg.inner_text("#messages"))
    pg.screenshot(path=SHOTS + "/error.png")
    pg.fill("#code", "int main() { printf(\"x\"); }"); pg.click("#generate-btn"); pg.wait_for_timeout(700)
    ok("unsupported construct explained", "Function calls are not supported" in pg.inner_text("#graph-error-text"))
    pg.fill("#code", "int main() { int x = 1; <img src=x onerror=alert(1)> }"); pg.click("#generate-btn"); pg.wait_for_timeout(700)
    ok("HTML in code is not rendered (XSS)", pg.locator("#graph-error img").count() == 0 and pg.locator("img[src='x']").count() == 0)
    # Ctrl+Enter, clear, reset
    pg.fill("#code", "int main() { int a = 1; if (a) { a = 2; } }"); pg.focus("#code"); pg.keyboard.press("Control+Enter"); pg.wait_for_timeout(700)
    ok("Ctrl+Enter generates", pg.inner_text("#m-decisions") == "1")
    pg.click("#clear-btn"); ok("clear empties editor and graph", pg.input_value("#code") == "" and pg.is_visible("#graph-empty"))
    pg.click("#generate-btn"); pg.wait_for_timeout(500)
    ok("empty input rejected clearly", "empty" in pg.inner_text("#graph-error-text").lower())
    pg.select_option("#example-select", "if"); pg.wait_for_timeout(700)
    pg.fill("#code", "garbage"); pg.click("#reset-btn"); pg.wait_for_timeout(700)
    ok("reset example restores code", "x > 5" in pg.input_value("#code"))
    pg.fill("#code", "x" * 20500); ok("character counter flags overflow", pg.locator("#count.over").count() == 1)
    pg.click("#generate-btn"); pg.wait_for_timeout(300)
    ok("client-side length limit enforced", "too long" in pg.inner_text("#graph-error-text"))

    # --- dead code & infinite loop visuals
    pg.select_option("#example-select", "dead-code"); pg.wait_for_timeout(800)
    ok("unreachable block flagged", pg.evaluate("() => CFGGraph.debug().nodes('.dead').length") == 1 and "unreachable" in pg.inner_text("#messages"))
    pg.select_option("#example-select", "infinite"); pg.wait_for_timeout(800)
    ok("infinite loop: EXIT dead, self back edge", pg.evaluate("() => CFGGraph.debug().getElementById('EXIT').hasClass('dead')") and pg.inner_text("#m-loops") == "1")
    pg.screenshot(path=SHOTS + "/infinite.png")
    with pg.expect_download() as d: pg.click("#export-svg")
    svg = open(d.value.path(), encoding="utf-8").read(); xml.dom.minidom.parseString(svg)
    ok("SVG with self-loop is well-formed", "C " in svg)

    # --- help dialog, fullscreen
    pg.click("#help-btn"); ok("help dialog opens", pg.is_visible("#help-dialog")); pg.keyboard.press("Escape")
    pg.select_option("#example-select", "nested-if"); pg.wait_for_timeout(800)
    pg.click("#fullscreen-btn"); pg.wait_for_timeout(600)
    fs = pg.evaluate("() => !!document.fullscreenElement || document.getElementById('graph-card').classList.contains('pseudo-fs')")
    ok("fullscreen view activates", fs)
    pg.screenshot(path=SHOTS + "/fullscreen.png")
    pg.click("#fullscreen-btn"); pg.wait_for_timeout(400)
    ok("fullscreen exits", pg.evaluate("() => !document.fullscreenElement && !document.getElementById('graph-card').classList.contains('pseudo-fs')"))

    # --- mobile layout
    m = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2).new_page()
    m.goto(BASE); m.wait_for_selector("#example-select option:nth-child(5)", state="attached")
    m.select_option("#example-select", "while"); m.wait_for_timeout(900)
    ok("mobile: no horizontal page overflow", m.evaluate("() => document.documentElement.scrollWidth <= window.innerWidth + 1"))
    m.screenshot(path=SHOTS + "/mobile.png", full_page=True)

    ok("no console errors/warnings in whole session", not errs, str(errs))
    b.close()

bad = [r for r in results if not r[1]]
print(f"\n{len(results)-len(bad)}/{len(results)} UI checks passed"); print("FAILED:", bad)
