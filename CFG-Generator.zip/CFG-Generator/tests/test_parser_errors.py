"""Input validation, syntax errors, unsupported syntax, grammar precedence, leaders."""

import unittest

from cfg_engine import CFGError, analyze_source
from cfg_engine import ast_nodes as A
from cfg_engine.cfg import find_leaders, form_blocks
from cfg_engine.ir import lower_program
from cfg_engine.parser import MAX_CODE_LENGTH, parse_source
from tests.helpers import wrap


def err(src):
    with unittest.TestCase().assertRaises(CFGError) as cm:
        analyze_source(src)
    return cm.exception


class InputValidationTests(unittest.TestCase):
    def test_empty_and_blank_input(self):
        for src in ["", "   \n\t  "]:
            e = err(src)
            self.assertEqual(e.category, "input")

    def test_non_string_input(self):
        with self.assertRaises(CFGError) as cm:
            analyze_source(None)
        self.assertEqual(cm.exception.category, "input")

    def test_input_too_long(self):
        e = err("int main() {" + " " * MAX_CODE_LENGTH + "}")
        self.assertEqual(e.category, "limit")

    def test_too_many_lines(self):
        e = err("int main() {" + "\n" * 1200 + "}")
        self.assertEqual(e.category, "limit")

    def test_nesting_too_deep(self):
        e = err("int main() {" + "{" * 60 + "}" * 60 + "}")
        self.assertEqual(e.category, "limit")

    def test_unterminated_comment(self):
        e = err("int main() { /* oops \n int x; }")
        self.assertEqual(e.category, "lexical")
        self.assertEqual(e.line, 1)


class SyntaxErrorTests(unittest.TestCase):
    def test_missing_semicolon_points_at_end_of_previous_statement(self):
        e = err("int main() {\n  int x = 5\n  x = 1;\n}")
        self.assertEqual(e.category, "syntax")
        self.assertEqual((e.line, e.column), (2, 12))
        self.assertIn("';'", e.message)

    def test_missing_expression_has_line_and_column(self):
        e = err("int main() {\n int x = ;\n}")
        self.assertEqual(e.category, "syntax")
        self.assertEqual((e.line, e.column), (2, 10))

    def test_missing_closing_brace(self):
        e = err("int main() {\n int x = 1;\n")
        self.assertEqual(e.category, "syntax")
        self.assertIn("end of file", e.message)

    def test_missing_paren(self):
        e = err("int main() { if (x > 1 { x = 1; } }")
        self.assertEqual(e.category, "syntax")
        self.assertIsNotNone(e.line)

    def test_else_without_if(self):
        e = err("int main() {\n  else { }\n}")
        self.assertIn("else", e.message)
        self.assertEqual((e.line, e.column), (2, 3))

    def test_wrong_main_signature(self):
        e = err("void main() { }")
        self.assertEqual(e.category, "syntax")

    def test_unexpected_character(self):
        e = err("int main() { int x = 1 @ 2; }")
        self.assertEqual(e.category, "unsupported")
        self.assertEqual((e.line, e.column), (1, 24))


class UnsupportedSyntaxTests(unittest.TestCase):
    def check(self, src, category, fragment):
        e = err(src)
        self.assertEqual(e.category, category, e.message)
        self.assertIn(fragment, e.message)
        self.assertIsNotNone(e.line)

    def test_function_call(self):
        self.check(wrap('int x; printf("hi");'), "unsupported", "printf")

    def test_other_function_definition(self):
        self.check("int f() { }\nint main() { }", "unsupported", "'f'")

    def test_switch(self):
        self.check(wrap("int x = 1; switch (x) { }"), "unsupported", "switch")

    def test_do_while(self):
        self.check(wrap("int x = 1; do { x++; } while (x < 3);"), "unsupported", "do-while")

    def test_goto(self):
        self.check(wrap("goto end;"), "unsupported", "goto")

    def test_float_type(self):
        self.check(wrap("float y = 1;"), "unsupported", "float")

    def test_float_literal(self):
        self.check(wrap("int y = 1.5;"), "unsupported", "floating")

    def test_arrays(self):
        self.check(wrap("int a[3];"), "unsupported", "arrays")

    def test_bitwise_and_ternary(self):
        self.check(wrap("int a = 1; int b = a & 2;"), "unsupported", "&&")
        self.check(wrap("int a = 1; int b = a ? 1 : 2;"), "unsupported", "ternary")

    def test_break_outside_loop_is_semantic_error(self):
        e = err(wrap("int x = 1;\nbreak;"))
        self.assertEqual(e.category, "semantic")
        self.assertEqual(e.line, 3)

    def test_continue_outside_loop(self):
        self.assertEqual(err(wrap("continue;")).category, "semantic")

    def test_unsupported_in_comment_is_ignored(self):
        analyze_source(wrap("// switch printf(\n int x = 1; /* goto */"))


def parse_stmt(text):
    program, _, _ = parse_source(wrap(text))
    return program.body.stmts[0]


class GrammarTests(unittest.TestCase):
    def test_precedence_mul_over_add(self):
        e = parse_stmt("int x = 1 + 2 * 3;").declarators[0][1]
        self.assertEqual(e.op, "+")
        self.assertEqual(e.right.op, "*")

    def test_left_associativity(self):
        e = parse_stmt("int x = 10 - 3 - 2;").declarators[0][1]
        self.assertEqual(e.op, "-")
        self.assertEqual(A.expr_to_str(e.left), "10 - 3")

    def test_and_binds_tighter_than_or(self):
        e = parse_stmt("int x = a || b && c;").declarators[0][1]
        self.assertEqual(e.op, "||")
        self.assertEqual(e.right.op, "&&")

    def test_relational_over_equality(self):
        e = parse_stmt("int x = a == b < c;").declarators[0][1]
        self.assertEqual(e.op, "==")
        self.assertEqual(e.right.op, "<")

    def test_unary_operators(self):
        e = parse_stmt("int x = -a * !b;").declarators[0][1]
        self.assertEqual(e.op, "*")
        self.assertIsInstance(e.left, A.Unary)
        self.assertEqual(e.left.op, "-")
        self.assertEqual(e.right.op, "!")

    def test_keyword_prefix_identifiers_are_names(self):
        s = parse_stmt("int interval = 1, format2 = 2;")
        self.assertEqual([d[0] for d in s.declarators], ["interval", "format2"])

    def test_compound_assignment_and_incdec(self):
        self.assertEqual(parse_stmt("x %= 3;").op, "%=")
        self.assertEqual(parse_stmt("x--;").op, "--")

    def test_nested_blocks_and_empty_statements(self):
        r = analyze_source(wrap("{ { int x = 1; ; } } ;"))
        self.assertEqual(r["metrics"]["basicBlocks"], 1)

    def test_main_void_parameter_accepted(self):
        analyze_source("int main(void) { return 0; }")


class LeaderTests(unittest.TestCase):
    def test_leaders_for_while_loop(self):
        # 0: i = 0;  1: branch  2: i++;  3: jump->1  4: return i;
        program, _, _ = parse_source(wrap("int i = 0; while (i < 3) { i++; } return i;"))
        instrs, label_pos, _ = lower_program(program)
        self.assertEqual([i.kind for i in instrs], ["stmt", "branch", "stmt", "jump", "return"])
        leaders = find_leaders(instrs, label_pos)
        self.assertEqual(leaders, [0, 1, 2, 4])
        blocks = form_blocks(instrs, leaders)
        self.assertEqual([(b.start, b.end) for b in blocks], [(0, 1), (1, 2), (2, 4), (4, 5)])

    def test_instruction_after_return_is_a_leader(self):
        program, _, _ = parse_source(wrap("return 1; int y = 2;"))
        instrs, label_pos, _ = lower_program(program)
        self.assertEqual(find_leaders(instrs, label_pos), [0, 1])

    def test_ir_rows_mark_leaders(self):
        r = analyze_source(wrap("int i = 0; while (i < 3) { i++; } return i;"))
        marked = [row["index"] for row in r["analysis"]["ir"] if row["isLeader"]]
        self.assertEqual(marked, r["analysis"]["leaders"])


if __name__ == "__main__":
    unittest.main()
