"""Small helpers for inspecting CFG results by content (not by fragile node ids)."""

from cfg_engine import analyze_source


def run(src):
    return analyze_source(src)


def nodes(r):
    return {n["id"]: n for n in r["graph"]["nodes"]}


def texts(node):
    t = [s["text"] for s in node["statements"]]
    if node["condition"]:
        t.append(node["condition"]["text"])
    return t


def find(r, text):
    """The single node containing a statement or condition with exactly this text."""
    hits = [n for n in r["graph"]["nodes"] if text in texts(n)]
    assert len(hits) == 1, f"expected exactly one node containing {text!r}, found {[h['id'] for h in hits]}"
    return hits[0]


def out(r, node_id):
    return sorted((e["target"], e["label"]) for e in r["graph"]["edges"] if e["source"] == node_id)


def out_edges(r, node_id):
    return [e for e in r["graph"]["edges"] if e["source"] == node_id]


def in_edges(r, node_id):
    return [e for e in r["graph"]["edges"] if e["target"] == node_id]


def target_of(r, node, label):
    es = [e for e in out_edges(r, node["id"]) if e["label"] == label]
    assert len(es) == 1, f"{node['id']} has {len(es)} edges labelled {label!r}"
    return nodes(r)[es[0]["target"]]


def wrap(body):
    return "int main() {\n" + body + "\n}\n"
