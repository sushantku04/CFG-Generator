"""CFG construction rules, checked on small hand-verified programs."""

import unittest

from cfg_engine import CFGError
from tests.helpers import find, in_edges, nodes, out, out_edges, run, target_of, texts, wrap


class SequentialTests(unittest.TestCase):
    def test_sequential_is_one_block(self):
        r = run(wrap("int a = 1; a = a + 2; return a;"))
        blocks = [n for n in r["graph"]["nodes"] if n["type"] == "block"]
        self.assertEqual(len(blocks), 1)
        self.assertEqual(texts(blocks[0]), ["int a = 1;", "a = a + 2;", "return a;"])
        self.assertEqual(out(r, "ENTRY"), [("B1", "")])
        self.assertEqual(out(r, "B1"), [("EXIT", "return")])
        self.assertEqual(r["metrics"]["cyclomaticComplexity"], 1)

    def test_falling_off_the_end_goes_to_exit(self):
        r = run(wrap("int a = 1; a = 2;"))
        self.assertEqual(out(r, "B1"), [("EXIT", "")])

    def test_empty_main_connects_entry_to_exit(self):
        r = run("int main() { }")
        self.assertEqual(len(r["graph"]["nodes"]), 2)
        self.assertEqual(out(r, "ENTRY"), [("EXIT", "")])
        self.assertEqual(r["metrics"]["cyclomaticComplexity"], 1)


class IfTests(unittest.TestCase):
    def test_if_without_else(self):
        # B1{x=1, x>0?}  B2{x=2}  B3{x=3}
        r = run(wrap("int x = 1; if (x > 0) { x = 2; } x = 3;"))
        dec = find(r, "x > 0")
        self.assertEqual(dec["type"], "decision")
        then = target_of(r, dec, "True")
        merge = target_of(r, dec, "False")
        self.assertEqual(texts(then), ["x = 2;"])
        self.assertEqual(texts(merge), ["x = 3;"])
        self.assertEqual(out(r, then["id"]), [(merge["id"], "")])
        self.assertEqual(len(r["graph"]["edges"]), 5)
        self.assertEqual(len(r["graph"]["nodes"]), 5)
        self.assertEqual(r["metrics"]["cyclomaticComplexity"], 2)

    def test_if_else_merges(self):
        r = run(wrap("int x = 1; int y; if (x > 0) { y = 1; } else { y = 2; } return y;"))
        dec = find(r, "x > 0")
        then, els = target_of(r, dec, "True"), target_of(r, dec, "False")
        self.assertEqual(texts(then), ["y = 1;"])
        self.assertEqual(texts(els), ["y = 2;"])
        merge = find(r, "return y;")
        self.assertEqual(out(r, then["id"]), [(merge["id"], "")])
        self.assertEqual(out(r, els["id"]), [(merge["id"], "")])
        self.assertEqual(len(in_edges(r, merge["id"])), 2)

    def test_nested_conditions(self):
        r = run(wrap(
            "int x = 4; int r;"
            "if (x > 0) { if (x > 10) { r = 2; } else { r = 1; } } else { r = 0; }"
            "return r;"))
        outer, inner = find(r, "x > 0"), find(r, "x > 10")
        self.assertEqual(target_of(r, outer, "True")["id"], inner["id"])
        self.assertEqual(texts(target_of(r, outer, "False")), ["r = 0;"])
        self.assertEqual(texts(target_of(r, inner, "True")), ["r = 2;"])
        self.assertEqual(texts(target_of(r, inner, "False")), ["r = 1;"])
        ret = find(r, "return r;")
        self.assertEqual(len(in_edges(r, ret["id"])), 3)
        self.assertEqual(r["metrics"]["decisionNodes"], 2)
        self.assertEqual(r["metrics"]["cyclomaticComplexity"], 3)

    def test_dangling_else_binds_to_nearest_if(self):
        r = run(wrap("int a = 1; int b = 1; int x; if (a) if (b) x = 1; else x = 2; return x;"))
        outer, inner = find(r, "a"), find(r, "b")
        self.assertEqual(texts(target_of(r, inner, "False")), ["x = 2;"])
        self.assertEqual(texts(target_of(r, outer, "False")), ["return x;"])

    def test_empty_if_body_sends_both_branches_to_same_block(self):
        r = run(wrap("int x = 1; if (x > 0) { } return x;"))
        dec = find(r, "x > 0")
        t, f = target_of(r, dec, "True"), target_of(r, dec, "False")
        self.assertEqual(t["id"], f["id"])
        self.assertEqual(len(out_edges(r, dec["id"])), 2)

    def test_empty_else_branch(self):
        r = run(wrap("int x = 1; if (x > 0) { x = 2; } else { } return x;"))
        dec = find(r, "x > 0")
        self.assertEqual(texts(target_of(r, dec, "False")), ["return x;"])


class LoopTests(unittest.TestCase):
    def test_while_loop_back_edge(self):
        r = run(wrap("int i = 0; while (i < 3) { i++; } return i;"))
        header = find(r, "i < 3")
        body = target_of(r, header, "True")
        after = target_of(r, header, "False")
        self.assertEqual(texts(body), ["i++;"])
        self.assertEqual(texts(after), ["return i;"])
        back = out_edges(r, body["id"])
        self.assertEqual(len(back), 1)
        self.assertEqual(back[0]["target"], header["id"])
        self.assertTrue(back[0]["isBack"])
        self.assertEqual(back[0]["label"], "back edge")
        self.assertEqual(r["metrics"]["loopBackEdges"], 1)
        self.assertEqual(sum(e["isBack"] for e in r["graph"]["edges"]), 1)
        # the entry into the loop is NOT a back edge
        self.assertFalse(any(e["isBack"] for e in in_edges(r, header["id"]) if e["source"] != body["id"]))

    def test_for_loop_structure(self):
        r = run(wrap("int t = 0; for (int i = 0; i < 4; i++) { t += i; } return t;"))
        init = find(r, "int i = 0;")
        self.assertIn("int t = 0;", texts(init))
        header = find(r, "i < 4")
        self.assertEqual(out(r, init["id"]), [(header["id"], "")])
        body = target_of(r, header, "True")
        self.assertEqual(texts(body), ["t += i;", "i++;"])  # body + update share a block (no continue)
        self.assertEqual(out(r, body["id"]), [(header["id"], "back edge")])
        self.assertEqual(texts(target_of(r, header, "False")), ["return t;"])

    def test_for_loop_with_continue_has_separate_update_block(self):
        r = run(wrap("int i; for (i = 0; i < 4; i++) { if (i == 1) { continue; } i += 0; } return i;"))
        update = find(r, "i++;")
        self.assertEqual(texts(update), ["i++;"])
        cont = [e for e in r["graph"]["edges"] if e["label"] == "continue"]
        self.assertEqual(len(cont), 1)
        self.assertEqual(cont[0]["target"], update["id"])

    def test_for_without_condition_is_unconditional(self):
        r = run(wrap("int x = 0; for (;;) { x++; }"))
        self.assertEqual(r["metrics"]["decisionNodes"], 0)
        self.assertFalse(r["metrics"]["exitReachable"])

    def test_empty_loop_body(self):
        r = run(wrap("int x = 1; while (x < 0) { } return x;"))
        header = find(r, "x < 0")
        # an empty body generates no block of its own: the True edge loops straight back
        loop_edge = [e for e in out_edges(r, header["id"]) if e["label"] == "True"][0]
        self.assertEqual(loop_edge["target"], header["id"])
        self.assertTrue(loop_edge["isBack"])
        self.assertEqual(texts(target_of(r, header, "False")), ["return x;"])
        self.assertEqual(r["metrics"]["loopBackEdges"], 1)

    def test_nested_loops_and_break_targets_inner_loop_only(self):
        r = run(wrap(
            "int i; int j; int x;"
            "for (i = 0; i < 2; i++) {"
            "  for (j = 0; j < 2; j++) { if (j == 1) { break; } }"
            "  x = 1;"
            "}"
            "return 0;"))
        brk = [e for e in r["graph"]["edges"] if e["label"] == "break"]
        self.assertEqual(len(brk), 1)
        after_inner = nodes(r)[brk[0]["target"]]
        self.assertIn("x = 1;", texts(after_inner))     # break leaves the INNER loop only
        self.assertEqual(r["metrics"]["loopBackEdges"], 2)

    def test_continue_in_nested_loop_targets_inner_update(self):
        r = run(wrap(
            "int i; int j;"
            "for (i = 0; i < 2; i++) { for (j = 0; j < 2; j++) { if (j == 0) { continue; } j += 0; } }"))
        cont = [e for e in r["graph"]["edges"] if e["label"] == "continue"]
        self.assertEqual(len(cont), 1)
        self.assertEqual(texts(nodes(r)[cont[0]["target"]]), ["j++;"])

    def test_while_true_has_no_exit_edge(self):
        r = run(wrap("int x = 0; while (1) { x++; }"))
        self.assertFalse(r["metrics"]["exitReachable"])
        self.assertEqual(in_edges(r, "EXIT"), [])
        exit_node = nodes(r)["EXIT"]
        self.assertFalse(exit_node["reachable"])
        self.assertTrue(any("never" in w["message"] or "unreachable" in w["message"] for w in r["warnings"]))

    def test_infinite_loop_does_not_hide_other_exit(self):
        r = run(wrap("int c = 1; if (c) { while (1) { } } return 0;"))
        self.assertTrue(r["metrics"]["exitReachable"])


class ReturnTests(unittest.TestCase):
    def test_return_only_goes_to_exit(self):
        r = run(wrap("int x = 1; if (x) { return 1; } return 2;"))
        for n in r["graph"]["nodes"]:
            if n["terminator"] == "return":
                self.assertEqual([(e["target"], e["label"]) for e in out_edges(r, n["id"])], [("EXIT", "return")])

    def test_multiple_return_paths(self):
        r = run(wrap("int x = 3; if (x < 0) { return 0; } if (x == 0) { return 1; } return 2;"))
        returns = [n for n in r["graph"]["nodes"] if n["terminator"] == "return"]
        self.assertEqual(len(returns), 3)
        self.assertEqual(len(in_edges(r, "EXIT")), 3)
        self.assertEqual(r["metrics"]["cyclomaticComplexity"], 3)
        self.assertEqual(r["metrics"]["unreachableNodes"], 0)

    def test_statement_after_return_is_unreachable_and_not_connected(self):
        r = run(wrap("int x = 1; return x; x = 2;"))
        dead = find(r, "x = 2;")
        self.assertFalse(dead["reachable"])
        self.assertEqual(in_edges(r, dead["id"]), [])           # nothing flows into dead code
        self.assertEqual(r["analysis"]["unreachable"], [{"id": dead["id"], "lines": dead["lines"]}])
        self.assertTrue(any("unreachable" in w["message"] for w in r["warnings"]))
        self.assertEqual(r["metrics"]["unreachableNodes"], 1)

    def test_code_after_return_inside_branch(self):
        r = run(wrap("int c = 1; int y; if (c) { return 1; y = 5; } y = 3; return y;"))
        self.assertFalse(find(r, "y = 5;")["reachable"])
        self.assertTrue(find(r, "y = 3;")["reachable"])
        dec = find(r, "c")
        self.assertEqual(texts(target_of(r, dec, "False")), ["y = 3;", "return y;"])

    def test_loop_ending_in_return_has_no_phantom_nodes(self):
        r = run(wrap("int i = 0; while (i < 3) { return i; } return 9;"))
        self.assertEqual(r["metrics"]["unreachableNodes"], 0)
        self.assertEqual(r["warnings"], [])

    def test_constant_false_condition_makes_body_unreachable(self):
        r = run(wrap("int x = 0; if (0) { x = 1; } x = 2;"))
        self.assertFalse(find(r, "x = 1;")["reachable"])
        self.assertTrue(any("constant false" in w["message"] for w in r["warnings"]))

    def test_constant_true_if_makes_else_unreachable(self):
        r = run(wrap("int x = 0; if (1) { x = 1; } else { x = 2; } return x;"))
        self.assertFalse(find(r, "x = 2;")["reachable"])
        self.assertTrue(find(r, "x = 1;")["reachable"])


class SourceInfoTests(unittest.TestCase):
    def test_line_numbers_are_preserved(self):
        src = "int main() {\n  int x = 1;\n\n  // comment\n  if (x > 0) {\n    x = 2;\n  }\n  return x;\n}\n"
        r = run(src)
        self.assertEqual(find(r, "int x = 1;")["lines"], [2, 5])  # shares a block with the if condition
        self.assertEqual(find(r, "x = 2;")["lines"], [6])
        self.assertEqual(find(r, "return x;")["lines"], [8])
        self.assertEqual(find(r, "x > 0")["condition"]["line"], 5)

    def test_preprocessor_line_is_reported_not_silent(self):
        r = run("#include <stdio.h>\nint main() {\n  int x = 1;\n}\n")
        self.assertTrue(any("Preprocessor" in w["message"] and w["line"] == 1 for w in r["warnings"]))
        self.assertEqual(find(r, "int x = 1;")["lines"], [3])

    def test_comments_are_ignored(self):
        r = run("int main() { /* block\n comment */ int x = 1; // trailing\n return x; }")
        self.assertEqual(texts(find(r, "int x = 1;")), ["int x = 1;", "return x;"])

    def test_expression_text_is_normalised(self):
        r = run(wrap("int x = 1+2*3-(4-5); x+=  -x; if(!x&&x<=3||x!=0){x=0;}"))
        self.assertEqual(find(r, "int x = 1 + 2 * 3 - (4 - 5);")["statements"][0]["line"], 2)
        self.assertEqual(r["graph"]["nodes"][1]["statements"][1]["text"], "x += -x;")
        self.assertEqual(find(r, "!x && x <= 3 || x != 0")["type"], "decision")


if __name__ == "__main__":
    unittest.main()
