"""Flask API tests (using the built-in test client - no server is started)."""

import json
import unittest

from app import MAX_REQUEST_BYTES, create_app
from cfg_engine.parser import MAX_CODE_LENGTH
from tests.helpers import wrap


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.client = create_app().test_client()

    def post(self, payload, **kw):
        return self.client.post("/api/generate-cfg", json=payload, **kw)

    def test_success_response_schema(self):
        resp = self.post({"code": wrap("int x = 1; if (x) { x = 2; } return x;")})
        self.assertEqual(resp.status_code, 200)
        body = resp.get_json()
        self.assertIs(body["success"], True)
        self.assertEqual(set(body), {"success", "graph", "metrics", "warnings", "analysis"})
        self.assertEqual(set(body["graph"]), {"nodes", "edges"})
        node = body["graph"]["nodes"][1]
        for key in ("id", "type", "statements", "condition", "lines", "terminator", "note", "reachable"):
            self.assertIn(key, node)
        edge = body["graph"]["edges"][0]
        for key in ("id", "source", "target", "label", "kind", "isBack", "reachable"):
            self.assertIn(key, edge)
        for key in ("basicBlocks", "decisionNodes", "cfgNodes", "cfgEdges", "cyclomaticComplexity"):
            self.assertIn(key, body["metrics"])
        self.assertEqual(body["metrics"]["decisionNodes"], 1)

    def test_syntax_error_response(self):
        resp = self.post({"code": "int main() {\n int x = ;\n}"})
        self.assertEqual(resp.status_code, 400)
        body = resp.get_json()
        self.assertIs(body["success"], False)
        self.assertEqual(body["category"], "syntax")
        self.assertEqual((body["line"], body["column"]), (2, 10))
        self.assertTrue(body["error"])
        self.assertNotIn("Traceback", json.dumps(body))

    def test_unsupported_error_category(self):
        body = self.post({"code": wrap('printf("x");')}).get_json()
        self.assertEqual(body["category"], "unsupported")

    def test_missing_code_field(self):
        resp = self.post({"source": "x"})
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.get_json()["category"], "input")

    def test_code_must_be_string(self):
        self.assertEqual(self.post({"code": 123}).status_code, 400)
        self.assertEqual(self.post({"code": ["a"]}).status_code, 400)

    def test_body_must_be_object(self):
        self.assertEqual(self.post([1, 2, 3]).status_code, 400)

    def test_malformed_json(self):
        resp = self.client.post("/api/generate-cfg", data="{not json", content_type="application/json")
        self.assertEqual(resp.status_code, 400)
        self.assertIs(resp.get_json()["success"], False)

    def test_non_json_content_type(self):
        resp = self.client.post("/api/generate-cfg", data="code=1", content_type="text/plain")
        self.assertEqual(resp.status_code, 415)
        self.assertIs(resp.get_json()["success"], False)

    def test_empty_code_rejected(self):
        resp = self.post({"code": "   "})
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.get_json()["category"], "input")

    def test_input_length_limit(self):
        resp = self.post({"code": "int main() {" + " " * (MAX_CODE_LENGTH + 5) + "}"})
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.get_json()["category"], "limit")

    def test_request_size_limit(self):
        resp = self.post({"code": "a" * (MAX_REQUEST_BYTES + 10)})
        self.assertEqual(resp.status_code, 413)
        self.assertIs(resp.get_json()["success"], False)

    def test_get_not_allowed_on_api(self):
        resp = self.client.get("/api/generate-cfg")
        self.assertEqual(resp.status_code, 405)
        self.assertIs(resp.get_json()["success"], False)

    def test_unknown_api_route_is_json(self):
        resp = self.client.get("/api/nope")
        self.assertEqual(resp.status_code, 404)
        self.assertIs(resp.get_json()["success"], False)

    def test_homepage_and_static_assets(self):
        home = self.client.get("/")
        self.assertEqual(home.status_code, 200)
        self.assertIn(b"CFG Studio", home.data)
        for path in ("/static/vendor/cytoscape.min.js", "/static/vendor/dagre.min.js",
                     "/static/vendor/cytoscape-dagre.js", "/static/js/app.js",
                     "/static/js/graph.js", "/static/js/editor.js", "/static/css/style.css"):
            self.assertEqual(self.client.get(path).status_code, 200, path)

    def test_security_headers_and_no_cors(self):
        resp = self.client.get("/")
        self.assertIn("default-src 'self'", resp.headers["Content-Security-Policy"])
        self.assertEqual(resp.headers["X-Content-Type-Options"], "nosniff")
        self.assertNotIn("Access-Control-Allow-Origin", resp.headers)

    def test_examples_endpoint(self):
        body = self.client.get("/api/examples").get_json()
        self.assertGreaterEqual(len(body["examples"]), 10)
        for ex in body["examples"]:
            for key in ("id", "name", "code", "expected", "explanation"):
                self.assertTrue(ex[key])

    def test_html_in_code_is_returned_as_data_only(self):
        # The server never renders submitted text as HTML; it appears only inside JSON.
        resp = self.post({"code": "int main() { <script>alert(1)</script> }"})
        self.assertEqual(resp.content_type, "application/json")
        self.assertEqual(resp.status_code, 400)


if __name__ == "__main__":
    unittest.main()
