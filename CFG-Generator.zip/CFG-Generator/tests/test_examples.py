"""Every built-in example must behave as its documentation says (computed, never drawn from this data)."""

import unittest

from cfg_engine import CFGError, analyze_source
from examples import EXAMPLES


class ExampleTests(unittest.TestCase):
    def test_all_examples_match_their_documented_structure(self):
        self.assertGreaterEqual(len(EXAMPLES), 10)
        for ex in EXAMPLES:
            with self.subTest(ex["id"]):
                for key in ("name", "code", "expected", "explanation", "check"):
                    self.assertTrue(ex[key] != "" and ex[key] is not None)
                check = ex["check"]
                if not check["valid"]:
                    with self.assertRaises(CFGError):
                        analyze_source(ex["code"])
                    continue
                m = analyze_source(ex["code"])["metrics"]
                for k, v in check.items():
                    if k != "valid":
                        self.assertEqual(m[k], v, f"{ex['id']}: {k}")

    def test_example_ids_unique(self):
        ids = [e["id"] for e in EXAMPLES]
        self.assertEqual(len(ids), len(set(ids)))


if __name__ == "__main__":
    unittest.main()
