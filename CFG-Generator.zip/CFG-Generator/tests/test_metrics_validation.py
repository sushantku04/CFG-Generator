"""Metrics, reachability, graph invariants and the validator."""

import copy
import unittest

from cfg_engine import analyze_source
from cfg_engine import analysis
from cfg_engine.cfg import CFG, Edge, Node
from tests.helpers import run, wrap

PROGRAMS = {
    "sequential": wrap("int a = 1; a = 2; return a;"),
    "if": wrap("int x = 1; if (x > 0) { x = 2; } return x;"),
    "if-else": wrap("int x = 1; if (x) { x = 2; } else { x = 3; } return x;"),
    "nested": wrap("int x = 1; if (x) { if (x > 2) { x = 1; } else { x = 2; } } return x;"),
    "while": wrap("int i = 0; while (i < 3) { i++; } return i;"),
    "for": wrap("int s = 0; for (int i = 0; i < 3; i++) { s += i; } return s;"),
    "two-loops": wrap("int i = 0; while (i < 3) { i++; } while (i > 0) { i--; } return i;"),
    "nested-loops": wrap("int i; int j; for (i = 0; i < 2; i++) { for (j = 0; j < 2; j++) { } } return 0;"),
    "multi-return": wrap("int x = 1; if (x) { return 1; } if (x > 1) { return 2; } return 3;"),
    "break-continue": wrap("int i; for (i = 0; i < 9; i++) { if (i == 2) { continue; } if (i == 5) { break; } }"),
    "loop-if": wrap("int i = 0; while (i < 9) { if (i % 2 == 0) { i += 2; } i++; } return i;"),
    "dead-code": wrap("int x = 1; return x; if (x) { x = 2; }"),
    "infinite": wrap("int x = 0; while (1) { x++; }"),
    "infinite-for": wrap("for (;;) { }"),
    "empty-bodies": wrap("int x = 1; if (x) { } while (x < 0) { }"),
    "const-if": wrap("int x = 0; if (0) { x = 1; } else { x = 2; }"),
}


class ComplexityTests(unittest.TestCase):
    expected = {  # hand-verified: decisions on the reachable path + 1
        "sequential": 1, "if": 2, "if-else": 2, "nested": 3, "while": 2, "for": 2,
        "two-loops": 3, "nested-loops": 3, "multi-return": 3, "break-continue": 4,
        "loop-if": 3, "dead-code": 1, "empty-bodies": 3,
    }

    def test_hand_verified_values(self):
        for name, m in self.expected.items():
            with self.subTest(name):
                self.assertEqual(run(PROGRAMS[name])["metrics"]["cyclomaticComplexity"], m)

    def test_graph_formula_matches_predicate_formula_when_exit_reachable(self):
        for name, src in PROGRAMS.items():
            m = run(src)["metrics"]
            if m["exitReachable"]:
                with self.subTest(name):
                    self.assertEqual(m["cyclomaticComplexity"], m["cyclomaticPredicateBased"])
                    self.assertTrue(m["conventionsAgree"])

    def test_formula_is_e_minus_n_plus_2p_on_reachable_subgraph(self):
        for name, src in PROGRAMS.items():
            r = run(src)
            reach = {n["id"] for n in r["graph"]["nodes"] if n["reachable"]}
            e = sum(1 for x in r["graph"]["edges"] if x["source"] in reach and x["target"] in reach)
            m = r["metrics"]
            with self.subTest(name):
                self.assertEqual(m["cyclomaticComplexity"], e - len(reach) + 2 * m["connectedComponents"])
                self.assertEqual(m["connectedComponents"], 1)

    def test_infinite_loop_conventions_differ_and_are_labelled(self):
        for name in ("infinite", "infinite-for"):
            m = run(PROGRAMS[name])["metrics"]
            with self.subTest(name):
                self.assertFalse(m["exitReachable"])
                self.assertEqual(m["cyclomaticComplexity"], 2)
                self.assertEqual(m["cyclomaticPredicateBased"], 1)
                self.assertFalse(m["conventionsAgree"])
                self.assertIn("EXIT is unreachable", m["conventionNote"])

    def test_unreachable_decision_is_not_counted(self):
        m = run(PROGRAMS["dead-code"])["metrics"]
        self.assertEqual(m["decisionNodes"], 1)           # present in the graph ...
        self.assertEqual(m["cyclomaticPredicateBased"], 1)  # ... but not on any path from ENTRY


class CountTests(unittest.TestCase):
    def test_counts_for_while_program(self):
        m = run(PROGRAMS["while"])["metrics"]
        self.assertEqual(m["basicBlocks"], 4)
        self.assertEqual(m["cfgNodes"], 6)       # + ENTRY + EXIT
        self.assertEqual(m["cfgEdges"], 6)       # entry, B1->B2, T, F, back, return
        self.assertEqual(m["decisionNodes"], 1)
        self.assertEqual(m["reachableNodes"], 6)
        self.assertEqual(m["unreachableNodes"], 0)
        self.assertEqual(m["loopBackEdges"], 1)

    def test_unreachable_counts(self):
        m = run(wrap("return 1; int y = 2; y = 3;"))["metrics"]
        self.assertEqual(m["unreachableNodes"], 1)
        self.assertEqual(m["reachableNodes"], m["cfgNodes"] - 1)


class InvariantTests(unittest.TestCase):
    def test_ids_unique_and_edge_endpoints_valid_everywhere(self):
        for name, src in PROGRAMS.items():
            r = run(src)
            ids = [n["id"] for n in r["graph"]["nodes"]]
            eids = [e["id"] for e in r["graph"]["edges"]]
            with self.subTest(name):
                self.assertEqual(len(ids), len(set(ids)))
                self.assertEqual(len(eids), len(set(eids)))
                for e in r["graph"]["edges"]:
                    self.assertIn(e["source"], ids)
                    self.assertIn(e["target"], ids)

    def test_branch_labels_and_successor_counts_everywhere(self):
        for name, src in PROGRAMS.items():
            r = run(src)
            for n in r["graph"]["nodes"]:
                outs = [e for e in r["graph"]["edges"] if e["source"] == n["id"]]
                with self.subTest(name=name, node=n["id"]):
                    if n["type"] == "decision":
                        self.assertEqual(sorted(e["label"] for e in outs), ["False", "True"])
                    elif n["type"] == "exit":
                        self.assertEqual(outs, [])
                    else:
                        self.assertEqual(len(outs), 1)
                        self.assertNotIn(outs[0]["label"], ("True", "False"))

    def test_entry_and_exit_rules(self):
        for name, src in PROGRAMS.items():
            r = run(src)
            with self.subTest(name):
                self.assertEqual([e for e in r["graph"]["edges"] if e["target"] == "ENTRY"], [])
                self.assertEqual(len([e for e in r["graph"]["edges"] if e["source"] == "ENTRY"]), 1)

    def test_validation_report_is_all_passed_for_every_program(self):
        for name, src in PROGRAMS.items():
            with self.subTest(name):
                v = run(src)["analysis"]["validation"]
                self.assertTrue(v["passed"])
                self.assertTrue(all(c["passed"] for c in v["checks"]))

    def test_back_edges_are_exactly_edges_into_dominating_nodes(self):
        r = run(PROGRAMS["nested-loops"])
        self.assertEqual(r["metrics"]["loopBackEdges"], 2)
        self.assertEqual(len(r["analysis"]["loops"]), 2)

    def test_no_back_edges_in_acyclic_graph(self):
        for name in ("if", "if-else", "nested", "multi-return"):
            self.assertEqual(run(PROGRAMS[name])["metrics"]["loopBackEdges"], 0)


def tiny_cfg():
    nodes = [Node("ENTRY", "entry"), Node("B1", "block", terminator="fallthrough"), Node("EXIT", "exit")]
    edges = [Edge("E1", "ENTRY", "B1", kind="entry"), Edge("E2", "B1", "EXIT")]
    return CFG(nodes=nodes, edges=edges, leaders=[], instrs=[], block_of_instr={})


class ValidatorTests(unittest.TestCase):
    def failed(self, cfg):
        v = analysis.validate(cfg)
        return [c["name"] for c in v["checks"] if not c["passed"]]

    def test_valid_graph_passes(self):
        self.assertEqual(self.failed(tiny_cfg()), [])

    def test_duplicate_node_id_detected(self):
        cfg = tiny_cfg()
        cfg.nodes.append(Node("B1", "block"))
        self.assertIn("Node IDs are unique", self.failed(cfg))

    def test_duplicate_edge_id_detected(self):
        cfg = tiny_cfg()
        cfg.edges[1].id = "E1"
        self.assertIn("Edge IDs are unique", self.failed(cfg))

    def test_dangling_edge_detected(self):
        cfg = tiny_cfg()
        cfg.edges.append(Edge("E3", "B1", "NOWHERE"))
        self.assertIn("All edge endpoints exist", self.failed(cfg))

    def test_bad_label_detected(self):
        cfg = tiny_cfg()
        cfg.edges[1].label = "maybe"
        self.assertIn("Edge labels are valid", self.failed(cfg))

    def test_decision_with_one_successor_detected(self):
        cfg = tiny_cfg()
        cfg.nodes[1].type = "decision"
        failed = self.failed(cfg)
        self.assertTrue(any("Decision nodes" in f for f in failed))

    def test_exit_with_successor_detected(self):
        cfg = tiny_cfg()
        cfg.edges.append(Edge("E3", "EXIT", "B1"))
        self.assertIn("EXIT has no outgoing edges", self.failed(cfg))

    def test_return_block_must_only_reach_exit(self):
        cfg = tiny_cfg()
        cfg.nodes[1].terminator = "return"
        self.assertTrue(any("return blocks" in f for f in self.failed(cfg)))


if __name__ == "__main__":
    unittest.main()
