@echo off
setlocal
cd /d "%~dp0"
title CFG Studio

echo.
echo  ============================================
echo   CFG Studio - Control Flow Graph Generator
echo  ============================================
echo.

rem ---- 1. find Python (py launcher first, then python) ----
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)
if not defined PY goto :nopython

%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 goto :oldpython

rem ---- 2. create the virtual environment once ----
if exist ".venv\Scripts\activate.bat" goto :activate
echo [setup] Creating virtual environment in .venv ...
%PY% -m venv .venv
if errorlevel 1 goto :venvfail

:activate
call ".venv\Scripts\activate.bat"

rem ---- 3. install dependencies only when requirements.txt changed ----
fc /b requirements.txt ".venv\requirements.installed" >nul 2>nul
if not errorlevel 1 goto :start
echo [setup] Installing dependencies - internet is needed only for this step ...
python -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :pipfail
copy /y requirements.txt ".venv\requirements.installed" >nul

rem ---- 4. start the app ----
:start
echo.
echo  CFG Studio is starting.
echo  Open this address in your browser:  http://127.0.0.1:5000
echo  Press Ctrl+C in this window to stop the server.
echo.
python app.py
echo.
echo  The server has stopped.
pause
exit /b 0

:nopython
echo [error] Python was not found.
echo         Install Python 3.10 or newer from https://www.python.org/downloads/
echo         and tick "Add python.exe to PATH" in the installer, then run this file again.
pause
exit /b 1

:oldpython
echo [error] Python 3.10 or newer is required. Your version is:
%PY% --version
echo         Install a newer Python from https://www.python.org/downloads/
pause
exit /b 1

:venvfail
echo [error] Could not create the virtual environment.
echo         Try the manual steps in README.md, or reinstall Python with the "venv" option.
pause
exit /b 1

:pipfail
echo [error] Installing the dependencies failed.
echo         Check your internet connection or proxy settings and run this file again.
echo         If a company or college network blocks pip, try a mobile hotspot for this step.
pause
exit /b 1
