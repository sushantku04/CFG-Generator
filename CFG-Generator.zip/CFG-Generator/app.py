"""CFG Studio - Flask application (development server).

Only parses and analyses the submitted text. Nothing is executed, written to disk
or stored. Run with:  python app.py   then open http://127.0.0.1:5000
"""

import os

from flask import Flask, jsonify, render_template, request

from cfg_engine import CFGError, analyze_source
from cfg_engine.parser import MAX_CODE_LENGTH
from examples import EXAMPLES

MAX_REQUEST_BYTES = 64 * 1024


def create_app():
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = MAX_REQUEST_BYTES
    app.config["JSON_SORT_KEYS"] = False

    def error(status, category, message, **extra):
        body = {"success": False, "category": category, "error": message,
                "line": extra.get("line"), "column": extra.get("column"), "hint": extra.get("hint")}
        return jsonify(body), status

    @app.after_request
    def security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.get("/")
    def index():
        return render_template("index.html", max_chars=MAX_CODE_LENGTH)

    @app.get("/api/examples")
    def examples():
        return jsonify({"examples": [{k: v for k, v in e.items() if k != "check"} for e in EXAMPLES]})

    @app.post("/api/generate-cfg")
    def generate_cfg():
        if not request.is_json:
            return error(415, "input", "Request must be JSON (Content-Type: application/json).")
        data = request.get_json(silent=True)
        if not isinstance(data, dict) or "code" not in data:
            return error(400, "input", "Request body must be a JSON object with a 'code' field.")
        code = data["code"]
        if not isinstance(code, str):
            return error(400, "input", "'code' must be a string.")
        try:
            return jsonify(analyze_source(code))
        except CFGError as e:
            status = 400 if e.category != "internal" else 500
            return error(status, e.category, e.message, line=e.line, column=e.column, hint=e.hint)
        except Exception:  # never expose a stack trace
            return error(500, "internal", "Unexpected server error.")

    @app.errorhandler(413)
    def too_large(_e):
        return error(413, "limit", f"Request is too large (limit {MAX_REQUEST_BYTES // 1024} KB).")

    @app.errorhandler(404)
    def not_found(_e):
        if request.path.startswith("/api/"):
            return error(404, "input", "Unknown API endpoint.")
        return "Not found", 404

    @app.errorhandler(405)
    def bad_method(_e):
        return error(405, "input", "Method not allowed for this endpoint.")

    @app.errorhandler(500)
    def server_error(_e):
        return error(500, "internal", "Unexpected server error.")

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("CFG_STUDIO_PORT", "5000"))
    print(f"\n  CFG Studio is running:  http://127.0.0.1:{port}\n  Press Ctrl+C to stop.\n")
    # Development server only; debug mode is intentionally OFF.
    app.run(host="127.0.0.1", port=port, debug=False)
