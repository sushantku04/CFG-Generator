# CFG Studio - Interactive Control Flow Graph Generator

Compiler Design mini-project - Fenil Sorathiya ,Sushant Kumar ,TANEESH KOMAL PATEL, B.Tech CSE (AI/ML), Karnavati University.

CFG Studio takes a small, clearly defined subset of C, parses it with a real grammar, lowers it to a
structured intermediate representation, finds **leaders**, forms **basic blocks**, builds the **Control Flow
Graph**, computes metrics, validates the graph and shows it interactively in the browser.
The graph is always computed from your code - nothing is hard-coded, faked or guessed by AI.

```
Source -> Lark LALR parser -> AST -> structured IR -> leaders -> basic blocks -> CFG edges
       -> dominators / back edges -> metrics + validation -> JSON -> Cytoscape.js
```

Everything runs on your own computer. No database, Docker, API key, cloud service or internet connection is
needed to generate a CFG (internet is needed once, only to install the Python packages).

## 1. Quick start (Windows 10/11)

1. Install **Python 3.10 or newer** from <https://www.python.org/downloads/> (tick *Add python.exe to PATH*).
2. Extract `CFG-Generator.zip` anywhere.
3. Double-click **`run.bat`**.
   - First run: creates `.venv`, installs the pinned packages (needs internet once), starts the server.
   - Later runs: starts immediately.
4. Open **<http://127.0.0.1:5000>** in your browser. Press `Ctrl+C` in the black window to stop.

### Manual alternative (any OS)

```
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

(macOS / Linux: `source .venv/bin/activate` instead of `.venv\Scripts\activate`.)
The app then listens on **http://127.0.0.1:5000**. To use another port: `set CFG_STUDIO_PORT=5050` before `python app.py`.

### Troubleshooting

| Problem | Fix |
|---|---|
| "Python was not found" | Install Python 3.10+ and tick *Add python.exe to PATH*; open a new window. |
| "Python 3.10 or newer is required" | Install a newer Python. |
| pip install fails | Check internet / proxy. On a restricted network try a phone hotspot for this one step. |
| "Address already in use" | Another program uses port 5000: set `CFG_STUDIO_PORT=5050` and open that port. |
| Browser shows nothing | Make sure the black server window is still open and use `http://127.0.0.1:5000` (not https). |

## 2. Using the application

* **Left:** source editor with line numbers, *Load example* menu (13 examples), **Generate CFG** (or `Ctrl+Enter`), *Clear*, *Reset example*, line/character count.
* **Centre:** analysis dashboard (blocks, decisions, nodes, edges, back edges, unreachable nodes, cyclomatic complexity) and the interactive graph - zoom, pan (drag), *Fit*, *Re-layout*, layout choice (top-bottom, left-right, breadth-first), *Fullscreen*, legend.
* **Right (Inspector):** click a node to see its ID, type, reachability, statements with source line numbers, incoming/outgoing edges and branch labels (predecessor/successor edges are highlighted); click an edge to see source, target, label and meaning.
* **Bottom:** *Messages* (parser errors with line/column, warnings, status), *IR & leaders* (the instruction list with leaders marked), *Validation* (structural checks), and **Export PNG / SVG / JSON**.
* Light/dark theme toggle and a *Help / About* dialog in the top bar.

Colours: green edge = True, red = False, purple dashed = loop back edge, dashed grey node = unreachable.

## 3. Supported C subset

```c
int main() {            // or int main(void)
    int x = 0, y;       // int declarations, optional initialisers
    x = x + 1;  x += 2; // = += -= *= /= %=
    x++;  y--;          // ++ / -- as statements
    if (x > 5 && !y) { ... } else { ... }
    while (x < 10) { ... }
    for (int i = 0; i < 4; i++) { ... }   // init, condition and update may each be omitted
    for (;;) { ... }                      // omitted condition = unconditional (infinite) loop
    break;  continue;   // correct semantics in nested loops
    return x;           // or: return;
    ;                   // empty statement,  { } nested blocks
}
```

Expressions (with C precedence): `* / %`, then `+ -`, then `< <= > >=`, then `== !=`, then `&&`, then `||`;
unary `-` and `!`; integer literals, variables, parentheses. Comments (`//`, `/* */`) are ignored.
Preprocessor lines such as `#include <stdio.h>` are skipped **with a warning** (never silently).
Everything else is rejected with an explanatory message - see `PROJECT_LIMITATIONS.md`.

## 4. How it works

| Stage | File | What happens |
|---|---|---|
| Grammar + parser | `cfg_engine/grammar.lark`, `parser.py` | Lark LALR(1) grammar; pre-checks (size, nesting, comments, `#` lines); unsupported-construct detection; Lark errors turned into messages with line/column. |
| AST | `ast_nodes.py` | Dataclasses for statements and expressions; expression printer. |
| Structured IR | `ir.py` | AST flattened to `stmt`, `branch`, `jump`, `return` instructions with labels (if/while/for/break/continue become jumps). |
| Leaders and blocks | `cfg.py` | **Leader algorithm** then block formation; edge construction; jump threading. |
| Analysis | `analysis.py` | Reachability, dominators, loop back edges, metrics, validation. |
| Pipeline / JSON | `engine.py` | Orchestration and serialisation. |
| Web | `app.py`, `templates/`, `static/` | Flask API + front end (Cytoscape.js + dagre layout). |

The engine (`cfg_engine/`) has no dependency on Flask or the browser.

### Leaders and basic blocks

A **leader** is the first instruction of a basic block:

1. the first instruction of the function;
2. every instruction that is the target of a jump or branch;
3. every instruction that immediately follows a jump, branch or return.

A basic block runs from one leader up to (not including) the next. The last instruction decides the successors:
branch -> `True` and `False` edges; jump -> its target; return -> `EXIT`; anything else -> fall through to the next block.
A `return` therefore never falls through, and code after it starts a block with no incoming edge - reported as **unreachable**.

*Cleanup (jump threading).* The raw leader method can create a block that contains only a compiler-generated jump
(for example the empty join after an if-else inside a loop). Such a block belongs to no source statement, so edges into it
are redirected to its successor and it is removed. User-written `break`/`continue` blocks are never removed, and a cycle made only
of such jumps (`while (1) { }`) is kept - it *is* the loop. The **IR & leaders** tab shows the unthreaded leaders.

*Constant conditions.* A literal condition (`if (0)`, `while (1)`, also `!1`, `(1)`) is folded: constant-true generates no branch (so
`while (1)` has **no exit edge** and `EXIT` is reported unreachable); constant-false jumps over the body (the body becomes unreachable).
A warning is shown each time. Only integer literals are folded - nothing else is evaluated.

### Metrics and conventions

* Blocks = basic blocks (without `ENTRY`/`EXIT`). Nodes = blocks + `ENTRY` + `EXIT`. Edges = all directed edges incl. `ENTRY -> first block`.
* **Cyclomatic complexity M = E - N + 2P**, computed on the sub-graph *reachable from ENTRY* (dead code adds no independent path). `ENTRY`/`EXIT` count as nodes and their edges as edges; P is the number of connected components of that sub-graph (always 1).
* Each `if`/`while`/`for` condition is **one** decision; `&&` and `||` are *not* counted separately.
* The dashboard also shows the cross-check **decisions + 1** (reachable decisions). For every program whose `EXIT` is reachable the two agree (tested). If `EXIT` is unreachable (infinite loop) `E - N + 2P` is one higher, because the exit edge is missing; the UI labels this instead of hiding it.
* **Loop back edge**: an edge u -> v where v dominates u (dominators computed iteratively).
* **Unreachable**: no path from `ENTRY`.

## 5. API

`POST /api/generate-cfg` with `{"code": "..."}` -> `{success, graph{nodes,edges}, metrics, warnings, analysis}` or
`{success:false, error, category, line, column, hint}`. Full schema: **`docs/API.md`**. Also `GET /api/examples`.

## 6. Security and privacy

* Submitted code is **only parsed**: no `eval`/`exec`, no shell, no file access, nothing executed, nothing stored or logged.
* Limits: 20,000 characters, 1,000 lines, nesting depth 40, 64 KB request body.
* Errors are JSON with readable text; stack traces are never returned. Flask debug mode is **off**; the server binds to `127.0.0.1` only. No CORS headers.
* Front end inserts all user/server text with `textContent` (no `innerHTML`); graph data is validated before rendering; a Content-Security-Policy (`script-src 'self'`) is sent.
* No analytics, tracking or external requests. The only thing stored in the browser is the theme choice.
* This is Flask's development server - fine for a demo on your own laptop, not for public hosting.

## 7. Offline use and third-party libraries

Graph libraries are **bundled** in `static/vendor/` (no CDN), so the app works with no internet after installation:

| Library | Version | Licence |
|---|---|---|
| Cytoscape.js | 3.30.2 | MIT (`LICENSE-cytoscape.txt`) |
| dagre | 0.8.5 | MIT (`LICENSE-dagre.txt`) |
| cytoscape-dagre | 2.5.0 | MIT (`LICENSE-cytoscape-dagre.txt`) |

Python packages are pinned in `requirements.txt` (Flask 3.0.3, Lark 1.2.2 and their dependencies).

## 8. Tests

```
python -m unittest discover -s tests -t . -v
```

106 tests: input validation, syntax/unsupported errors with positions, grammar precedence, leaders, every CFG rule (sequential, if, if-else,
nested, while, for, return, multiple returns, dead code, empty branches/bodies, nested loops with break/continue, infinite loops),
node/edge invariants, validator, metrics (hand-verified values and cross-checks), API success/error/limits, and the built-in examples.

Optional real-browser check (needs `pip install -r requirements-dev.txt` and `python -m playwright install chromium`; start the app first):

```
python tests/ui_browser_check.py
```

## 9. Project layout

```
app.py  examples.py  run.bat  requirements.txt  requirements-dev.txt  .gitignore
cfg_engine/   grammar.lark parser.py ast_nodes.py ir.py cfg.py analysis.py engine.py errors.py
templates/index.html
static/       css/style.css  js/{app,graph,editor,theme-init}.js  vendor/ (Cytoscape, dagre, licences)
tests/        helpers.py test_*.py  ui_browser_check.py
docs/         API.md  screenshots/
README.md  REPORT.md  DEMO_GUIDE.md  PROJECT_LIMITATIONS.md  BUILD_REPORT.md
```
