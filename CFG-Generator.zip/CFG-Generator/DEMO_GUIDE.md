# Demo guide - CFG Studio (Compiler Design mini-project)

Student:Fenil Sorathiya, Sushant Kumar , TANEESH KOMAL PATEL - B.Tech CSE (AI/ML) - Karnavati University

## 0. Before the evaluation (5 minutes)

* Double-click `run.bat`, open <http://127.0.0.1:5000>, click **Generate CFG** once to confirm everything works.
* Keep the black server window open. Have `REPORT.md` / your uploaded report ready.
* Be ready to open `cfg_engine/grammar.lark`, `cfg_engine/cfg.py` (function `find_leaders`) and `cfg_engine/ir.py` in an editor - evaluators like to see the real code.
* Everything you say must match what the tool does. Read `PROJECT_LIMITATIONS.md` once.

## 1. Presentation script (4-5 minutes)

**0:00 - Problem and goal (30 s)**
"Good morning. My project is CFG Studio, an interactive Control Flow Graph generator. A control flow graph is the representation a compiler uses to
reason about a program - nodes are basic blocks, edges are possible jumps. It is the base for optimisation, dead-code detection and complexity metrics.
My tool takes a C subset, builds the CFG with the real compiler algorithm, and lets you explore it."

**0:30 - Pipeline (45 s)** (show the Help dialog or README diagram)
"The pipeline is: source, Lark LALR parser, AST, a structured IR with explicit jumps, the *leader algorithm*, basic blocks, CFG edges, then dominators for loop back edges,
metrics and validation, and finally JSON to the browser where Cytoscape.js draws it. The graph is never hard-coded - I will show you by editing the code live."

**1:15 - Live demo (2 min 30 s)** (see sequence in section 2)

**3:45 - What makes it correct (30 s)**
"Return has no fall-through, so code after it is flagged unreachable. break and continue jump to the right loop in nested loops. Infinite loops get no fake exit edge.
There are 106 automated tests plus a real-browser check, and a validator checks every graph: unique IDs, valid endpoints, every decision has exactly one True and one False edge."

**4:15 - Limitations and close (30 s)**
"It supports an int-only subset of C with one main function. It does not do semantic analysis or short-circuit expansion; those are in my future scope. Thank you - I can take questions."

## 2. Demo sequence

1. **Sequential** (example 1): one block, no decision, complexity 1. Click the block -> inspector shows statements with line numbers.
2. **If-else** (example 3): decision diamond, green True edge, red False edge, merge block. Click the decision -> incoming/outgoing edges highlighted.
3. **While loop** (example 5): purple dashed *back edge*. Open **IR & leaders**: point at the leader marks (loop header is a leader because of the back jump).
4. **Live edit**: change `i < 5` to `i < 5 && i != 2`, press `Ctrl+Enter` - same shape (one decision; explain why: && is not split in this tool). Then change the loop to `for (...)` and generate again.
5. **Break and continue** (example 12): `continue` edge goes to `i++`, `break` edge goes to the `return`.
6. **Return / dead code** (example 10): the dashed grey block is unreachable; a warning appears in *Messages*.
7. **Infinite loop** (example 11): EXIT is dashed grey, no edge into it; point at "decisions + 1" note explaining why the two complexity values differ.
8. **Invalid syntax** (example 13): error with line and column, line marked in the gutter, no graph.
9. **Export**: PNG, SVG, JSON. Toggle dark theme. Show *Fullscreen*.
10. (If asked) run `python -m unittest discover -s tests -t . -v`.

## 3. Sample programs to type live

```c
int main() { int x = 0; while (x < 3) { if (x == 1) { x += 2; } else { x++; } } return x; }
```
```c
int main() { int i; for (i = 0; i < 9; i++) { if (i == 2) continue; if (i == 5) break; } return i; }
```
```c
int main() { int x = 1; if (x > 0) { return 1; } return 0; x = 5; }
```

## 4. What to explain to the evaluator

* **Leaders**: first instruction; jump/branch targets; instruction after a jump/branch/return. Block = leader up to next leader.
* **Edges**: decided by the last instruction of a block (branch -> True/False; jump -> target; return -> EXIT; else fall through).
* **Loop back edge**: edge to a node that dominates its source (dominators computed iteratively).
* **Cyclomatic complexity**: M = E - N + 2P on the reachable graph; cross-checked with decisions + 1.
* **Honesty points**: constant conditions are folded only for integer literals; compiler-generated jump-only blocks are removed (jump threading); no semantic analysis; Flask dev server only.
* **Security**: the code is parsed, never executed; limits on size; output escaped.

## 5. Likely viva questions and answers

1. **What is a basic block?** A maximal sequence of instructions with one entry point (the first) and one exit (the last); no jumps into the middle, no jumps out except at the end.
2. **What is a leader and how do you find leaders?** The first instruction of a block: the first instruction of the function, any jump/branch target, and any instruction following a jump/branch/return (`find_leaders` in `cfg.py`).
3. **What is a Control Flow Graph?** A directed graph whose nodes are basic blocks and whose edges are possible transfers of control; plus Entry and Exit nodes.
4. **Why do you need an IR instead of building the graph from the AST directly?** The leader algorithm works on a linear instruction list with jumps; lowering if/while/for/break/continue to jumps makes block formation uniform and correct.
5. **Which parsing technique do you use?** LALR(1) via the Lark library with a contextual lexer; the grammar encodes operator precedence by levels (`||` < `&&` < equality < relational < additive < multiplicative < unary).
6. **How is the dangling-else problem handled?** LALR resolves the shift/reduce conflict by shifting, so `else` binds to the nearest `if` - there is a test for it.
7. **How do you handle `return`?** It is a terminator: its only edge goes to EXIT. The next instruction is a leader with no incoming edge, so it is reported unreachable.
8. **How are `break` and `continue` handled?** The lowerer keeps a stack of (break label, continue label); break jumps to the loop end, continue to the condition (while) or the update (for). Tested with nested loops.
9. **What is a loop back edge and how do you detect it?** An edge u -> v where v dominates u. I compute dominators with the standard iterative data-flow algorithm on the reachable graph.
10. **What is cyclomatic complexity and what convention do you use?** McCabe's M = E - N + 2P. I compute it on the reachable subgraph, count ENTRY/EXIT as nodes, count each condition once, and cross-check with decisions + 1.
11. **Why can the two complexity values differ for an infinite loop?** With no reachable EXIT the exit edge is missing, so E - N + 2P is one higher than decisions + 1. The tool shows both and explains.
12. **What is an unreachable block?** A block with no path from ENTRY, e.g. code after `return` or the body of `if (0)`.
13. **Is the graph hard-coded for the examples?** No. Examples are only source text. Expected values in `examples.py` are checked by tests against what the engine computes.
14. **What does jump threading do and why?** The leader method can leave a block containing only a compiler-generated jump (like an empty join). I redirect edges around it so the graph shows only blocks that correspond to source code.
15. **What is not supported?** Other functions and calls, types other than int, arrays/pointers/strings, switch, do-while, goto, ternary, bitwise operators. They are rejected with clear messages.
16. **Where can this be used in real compilers?** Optimisation (dead-code elimination, loop optimisations), data-flow analysis (liveness, reaching definitions), SSA construction, static analysis and testing metrics.
17. **How is the app secured?** The server never executes the code; request/input limits; JSON-only errors without stack traces; no innerHTML; CSP; localhost-only binding; Flask debug off.
18. **How would you extend it?** Short-circuit expansion of `&&`/`||`, functions with a call graph, data-flow analyses on the CFG, dominator tree view, DOT export.
