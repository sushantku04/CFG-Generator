"""Built-in example programs.

Each example documents its expected structure. These numbers are NOT used to draw
anything - the graph is always computed from the source. They exist for the UI
description and are verified against the real engine by tests/test_examples.py.
"""

EXAMPLES = [
    {
        "id": "sequential",
        "name": "1. Sequential statements",
        "code": "int main() {\n    int a = 5;\n    int b = a * 2;\n    int c = a + b;\n    return c;\n}\n",
        "expected": "One basic block (all four statements) between ENTRY and EXIT. No decisions, complexity 1.",
        "explanation": "Straight-line code has a single leader (the first instruction), so it forms one basic block.",
        "check": {"valid": True, "basicBlocks": 1, "decisionNodes": 0, "cyclomaticComplexity": 1},
    },
    {
        "id": "if",
        "name": "2. Simple if",
        "code": "int main() {\n    int x = 7;\n    if (x > 5) {\n        x = x - 5;\n    }\n    return x;\n}\n",
        "expected": "Decision x > 5 with a True edge to the body and a False edge straight to the merge block (return).",
        "explanation": "The instruction after the if body is a leader because both branches reach it.",
        "check": {"valid": True, "basicBlocks": 3, "decisionNodes": 1, "cyclomaticComplexity": 2},
    },
    {
        "id": "if-else",
        "name": "3. If-else",
        "code": "int main() {\n    int x = 3;\n    int y;\n    if (x > 5) {\n        y = 1;\n    } else {\n        y = 2;\n    }\n    return y;\n}\n",
        "expected": "One decision, two branch blocks (then / else) that merge into the return block.",
        "explanation": "Both arms fall into the same merge block; the then-arm jumps over the else-arm.",
        "check": {"valid": True, "basicBlocks": 4, "decisionNodes": 1, "cyclomaticComplexity": 2},
    },
    {
        "id": "nested-if",
        "name": "4. Nested if-else",
        "code": "int main() {\n    int x = 4;\n    int r;\n    if (x > 0) {\n        if (x > 10) {\n            r = 2;\n        } else {\n            r = 1;\n        }\n    } else {\n        r = 0;\n    }\n    return r;\n}\n",
        "expected": "Two decision nodes (x > 0 and x > 10), three assignment blocks and the return block (the arms merge there). Complexity 3.",
        "explanation": "The inner if-else sits inside the True arm of the outer decision; all arms merge at the return.",
        "check": {"valid": True, "basicBlocks": 6, "decisionNodes": 2, "cyclomaticComplexity": 3},
    },
    {
        "id": "while",
        "name": "5. While loop",
        "code": "int main() {\n    int i = 0;\n    int sum = 0;\n    while (i < 5) {\n        sum = sum + i;\n        i++;\n    }\n    return sum;\n}\n",
        "expected": "Condition block i < 5 is the loop header; body has a back edge to it; False edge leaves the loop.",
        "explanation": "The loop header is a leader because the end of the body jumps back to it (back edge).",
        "check": {"valid": True, "basicBlocks": 4, "decisionNodes": 1, "cyclomaticComplexity": 2, "loopBackEdges": 1},
    },
    {
        "id": "for",
        "name": "6. For loop",
        "code": "int main() {\n    int total = 0;\n    for (int i = 0; i < 4; i++) {\n        total += i;\n    }\n    return total;\n}\n",
        "expected": "Init block, condition decision, one body+update block (i++ ends it) with a back edge to the condition, then return.",
        "explanation": "A for loop is lowered to: init; header (condition); body; update; jump back. With no continue, the update is not a leader, so it stays in the body block.",
        "check": {"valid": True, "basicBlocks": 4, "decisionNodes": 1, "cyclomaticComplexity": 2, "loopBackEdges": 1},
    },
    {
        "id": "multi-return",
        "name": "7. Multiple return statements",
        "code": "int main() {\n    int x = 3;\n    if (x < 0) {\n        return 0;\n    }\n    if (x == 0) {\n        return 1;\n    }\n    return 2;\n}\n",
        "expected": "Three return blocks, each with a single edge to EXIT. Two decisions, complexity 3.",
        "explanation": "A return ends the path: its only successor is EXIT, never the next statement.",
        "check": {"valid": True, "basicBlocks": 5, "decisionNodes": 2, "cyclomaticComplexity": 3},
    },
    {
        "id": "loop-if",
        "name": "8. Loop with a conditional",
        "code": "int main() {\n    int i = 0;\n    int evens = 0;\n    while (i < 10) {\n        if (i % 2 == 0) {\n            evens++;\n        }\n        i++;\n    }\n    return evens;\n}\n",
        "expected": "A while header and an if decision inside the loop; the merge block increments i and jumps back.",
        "explanation": "Nested control flow: the if's merge block ends with the loop's back edge.",
        "check": {"valid": True, "basicBlocks": 6, "decisionNodes": 2, "cyclomaticComplexity": 3, "loopBackEdges": 1},
    },
    {
        "id": "empty",
        "name": "9. Empty body",
        "code": "int main() {\n    int x = 1;\n    if (x > 0) {\n    }\n    while (x < 0) {\n    }\n    return x;\n}\n",
        "expected": "The empty if sends both True and False to the same block. The empty while body has no block: its True edge loops straight back to the condition.",
        "explanation": "Empty bodies generate no statements, but the control flow (branches, back edge) is still correct.",
        "check": {"valid": True, "basicBlocks": 3, "decisionNodes": 2, "cyclomaticComplexity": 3, "loopBackEdges": 1},
    },
    {
        "id": "dead-code",
        "name": "10. Unreachable code after return",
        "code": "int main() {\n    int x = 1;\n    return x;\n    x = 2;\n}\n",
        "expected": "The statement after return forms a block that nothing reaches; it is flagged unreachable.",
        "explanation": "A return has no fall-through edge, so the next instruction is a leader with no incoming edge.",
        "check": {"valid": True, "unreachableNodes": 1, "cyclomaticComplexity": 1},
    },
    {
        "id": "infinite",
        "name": "11. Infinite loop",
        "code": "int main() {\n    int x = 0;\n    for (;;) {\n        x++;\n    }\n}\n",
        "expected": "Body block loops to itself; EXIT is unreachable and flagged. No fake exit edge is drawn.",
        "explanation": "An omitted for-condition means 'always true', so the loop has no exit edge.",
        "check": {"valid": True, "exitReachable": False, "loopBackEdges": 1},
    },
    {
        "id": "break-continue",
        "name": "12. break and continue",
        "code": "int main() {\n    int i;\n    for (i = 0; i < 10; i++) {\n        if (i == 3) {\n            continue;\n        }\n        if (i == 7) {\n            break;\n        }\n    }\n    return i;\n}\n",
        "expected": "continue jumps to the update (i++); break jumps to the statement after the loop.",
        "explanation": "break/continue are jumps with loop-specific targets, handled correctly in nested loops.",
        "check": {"valid": True, "decisionNodes": 3, "cyclomaticComplexity": 4},
    },
    {
        "id": "invalid",
        "name": "13. Invalid syntax",
        "code": "int main() {\n    int x = 5\n    if (x > 3 {\n        x = 1;\n    }\n}\n",
        "expected": "A syntax error with line and column; no graph is drawn.",
        "explanation": "The parser rejects the program (missing ';' and ')') and reports the position.",
        "check": {"valid": False},
    },
]
