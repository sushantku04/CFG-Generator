# CFG Studio API

Base URL: `http://127.0.0.1:5000`. All API responses are JSON (`Cache-Control: no-store`). No CORS headers are sent.

## POST /api/generate-cfg

Request: `Content-Type: application/json`, body `{"code": "<C source text>"}`.
Limits: body <= 64 KB; `code` <= 20,000 characters, <= 1,000 lines, nesting <= 40.

### Success - HTTP 200

```jsonc
{
  "success": true,
  "graph": {
    "nodes": [{
      "id": "B2",                       // ENTRY, EXIT, B1, B2, ...
      "type": "decision",               // entry | exit | block | decision
      "statements": [{"text": "i = 0;", "line": 2}],   // simple statements in the block (incl. return / break / continue)
      "condition": {"text": "i < 10", "line": 4},      // only for decision nodes, else null
      "lines": [2, 4],                  // sorted source lines contributing to the block
      "terminator": "branch",           // fallthrough | branch | jump | return | none
      "note": "",                       // extra explanation (e.g. constant-false jump), may be empty
      "reachable": true                 // path exists from ENTRY
    }],
    "edges": [{
      "id": "E3", "source": "B2", "target": "B3",
      "label": "True",                  // "", True, False, return, break, continue, back edge
      "kind": "true",                   // entry | sequential | jump | true | false | return
      "isBack": false,                  // loop back edge (target dominates source)
      "reachable": true                 // source is reachable
    }]
  },
  "metrics": {
    "basicBlocks": 6, "decisionNodes": 2, "cfgNodes": 8, "cfgEdges": 9,
    "reachableNodes": 8, "unreachableNodes": 0, "loopBackEdges": 1, "connectedComponents": 1,
    "cyclomaticComplexity": 3,          // E - N + 2P on the sub-graph reachable from ENTRY
    "cyclomaticPredicateBased": 3,      // reachable decisions + 1 (cross-check)
    "conventionsAgree": true, "conventionNote": "Both conventions agree.",
    "exitReachable": true, "convention": "M = E - N + 2P, computed on ..."
  },
  "warnings": [{"line": 7, "message": "Block B4 (line 7) is unreachable."}],   // line may be null
  "analysis": {
    "validation": {"passed": true, "checks": [{"name": "...", "passed": true, "detail": ""}]},
    "unreachable": [{"id": "B4", "lines": [7]}],
    "loops": [{"header": "B2", "backEdges": ["E8"]}],
    "leaders": [0, 2, 3],               // instruction indices (leader algorithm, before cleanup)
    "ir": [{"index": 0, "kind": "stmt", "text": "int i = 0;", "line": 2, "isLeader": true, "block": "B1", "synthetic": false}],
    "stages": ["parse (Lark LALR)", "AST", "..."]
  }
}
```

Node and edge IDs match `^[A-Za-z0-9_]{1,32}$`. `ir[].block` is `null` for compiler-generated jump rows that were merged away.

### Error - HTTP 400 / 413 / 415 / 405 / 404 / 500

```json
{"success": false, "category": "syntax", "error": "Expected ';' before 'if'.", "line": 2, "column": 14, "hint": "A ';' is probably missing at the end of this statement."}
```

`line`, `column`, `hint` may be `null`. Categories:

| category | meaning | HTTP |
|---|---|---|
| `input` | empty code, wrong JSON shape / type, unknown route or method | 400 / 404 / 405 / 415 |
| `lexical` | invalid character, unterminated comment | 400 |
| `syntax` | grammar violation | 400 |
| `unsupported` | valid C but outside the supported subset | 400 |
| `semantic` | e.g. `break` outside a loop | 400 |
| `limit` | too long, too many lines, too deeply nested, request too large | 400 / 413 |
| `internal` | unexpected failure (details are never exposed) | 500 |

## GET /api/examples

`{"examples": [{"id", "name", "code", "expected", "explanation"}, ...]}` - the built-in programs. The text under
`expected` documents the structure to look for; the graph itself is always computed.
