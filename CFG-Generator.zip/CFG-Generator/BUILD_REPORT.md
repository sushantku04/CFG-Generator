# BUILD_REPORT - CFG Studio

Build date: 2026-10-29 (build environment clock). This file records what was actually built and run.

## Implemented features

* Lark LALR(1) grammar for a C subset (`int main`, int declarations, assignments incl. compound, `++`/`--`, if, if-else, while, for, break, continue, return, blocks, empty statements, full expression precedence, unary `-` `!`).
* AST -> structured IR -> **leader algorithm** -> basic blocks -> CFG with ENTRY/EXIT, True/False/return/break/continue/back-edge labels, jump-threading cleanup.
* Reachability, dominators, loop back edges, metrics (blocks, decisions, nodes, edges, reachable/unreachable, back edges, cyclomatic complexity `E - N + 2P` with a `decisions + 1` cross-check) and a structural validator.
* Constant literal conditions folded (with warnings); preprocessor lines skipped with warnings; unsupported syntax rejected with explanations; size/line/nesting limits.
* Flask API (`POST /api/generate-cfg`, `GET /api/examples`), JSON errors with category/line/column, security headers, no CORS, debug off, localhost only.
* Front end "CFG Studio": editor with line numbers and error/warning markers, 13 examples, dashboard, interactive Cytoscape.js graph (dagre layouts: top-bottom, left-right, breadth-first; zoom, pan, fit, re-layout, fullscreen, legend), node/edge inspector with highlighting, IR & leaders tab, validation tab, light/dark theme, PNG/SVG/JSON export, Help/About dialog, responsive layout.
* Documentation: README.md, docs/API.md, REPORT.md (draft), DEMO_GUIDE.md, PROJECT_LIMITATIONS.md, this file. Real screenshots in docs/screenshots/.

## Architecture

`cfg_engine/` (grammar.lark, parser.py, ast_nodes.py, ir.py, cfg.py, analysis.py, engine.py, errors.py) is independent of Flask.
`app.py` (Flask) -> `templates/index.html` + `static/` (css, js, bundled vendor libraries). See README.md section 4.

## Environment and dependencies

* Python used for build and tests: **3.12.3** (Linux). The project requires Python 3.10+ (pinned `click==8.3.1` needs it); other Python versions were not tested.
* Pinned packages (`requirements.txt`): Flask 3.0.3, Werkzeug 3.1.7, Jinja2 3.1.6, MarkupSafe 3.0.3, itsdangerous 2.2.0, click 8.3.1, blinker 1.9.0, lark 1.2.2. (`colorama` is installed automatically by click on Windows.)
* Bundled front-end libraries (MIT): Cytoscape.js 3.30.2, dagre 0.8.5, cytoscape-dagre 2.5.0 - no CDN, no internet needed to run.
* Optional browser-check dependency (`requirements-dev.txt`): Playwright 1.56.0 with Chromium.

## Test commands

```
python -m unittest discover -s tests -t . -v        # 106 unit + API tests
python app.py                                        # then, in another terminal:
python tests/ui_browser_check.py                     # optional real-browser check (needs requirements-dev.txt)
```

## Actual results

Unit and API tests (run in the project folder and again in a fresh virtual environment created from the extracted ZIP with `pip install -r requirements.txt`):

```
----------------------------------------------------------------------
Ran 106 tests in 0.253s

OK
```

Per module: test_api 17, test_cfg_structure 29, test_examples 2, test_metrics_validation 21, test_parser_errors 37 (total 106).

Real-browser check (headless Chromium 1194 build via Playwright 1.56.0 on Linux, against the running app; also run against the extracted ZIP in a fresh venv, 44/44):

```
PASS empty state visible before generation 
PASS export buttons disabled before generation 
PASS metrics shown 
PASS graph rendered in Cytoscape {'n': 8, 'e': 9, 'back': 1}
PASS node click shows inspector (id, statements, edges) Decision Node ID B2 Node type decision Reachable yes Source lines 4 Ends with co
PASS node selected; incoming and outgoing edges highlighted {'sel': ['B2'], 'in': 2, 'out': 2}
PASS source lines highlighted in editor gutter 
PASS clicking selected node again clears selection 
PASS edge click shows source/target/label Edge E8 Edge ID E8 Source B5 Target B2 Branch label back edge Meaning Unconditional jump Loop back e
PASS edge highlighted 
PASS clicking empty canvas clears selection 
PASS zoom in / out change zoom 0.71 0.89 0.57
PASS fit restores overall view 0.71
PASS left-to-right layout puts EXIT right of ENTRY [48.8, 922.6937499999999]
PASS breadth-first layout works 
PASS IR tab lists leaders 
PASS validation tab lists passed checks 
PASS PNG export is a real PNG with size 980x1106 131030 bytes
PASS SVG export is well-formed XML 
PASS SVG contains all nodes' text, paths for edges paths=13 polygons=2
PASS JSON export has source, graph, metrics 
PASS dark theme applied 
PASS SVG export follows theme 
PASS theme persisted across reload 
PASS error overlay shown with position Syntax error (line 2, column 14)
PASS error line marked in gutter 
PASS exports disabled after error; metrics reset 
PASS message links to the source line 
PASS unsupported construct explained 
PASS HTML in code is not rendered (XSS) 
PASS Ctrl+Enter generates 
PASS clear empties editor and graph 
PASS empty input rejected clearly 
PASS reset example restores code 
PASS character counter flags overflow 
PASS client-side length limit enforced 
PASS unreachable block flagged 
PASS infinite loop: EXIT dead, self back edge 
PASS SVG with self-loop is well-formed 
PASS help dialog opens 
PASS fullscreen view activates 
PASS fullscreen exits 
PASS mobile: no horizontal page overflow 
PASS no console errors/warnings in whole session []
44/44 UI checks passed
FAILED: []
```

Manual workflow verification done during the build (screenshots in docs/screenshots/): homepage loads; all examples generate (invalid-syntax example shows an error); node and edge inspection; exports produce a valid PNG, a well-formed SVG (rendered and visually checked) and a JSON file.

## Acceptance checklist

| Item | Status |
|---|---|
| Application starts; homepage loads | Done (Linux, Flask dev server) |
| Examples work; invalid syntax gives a useful error | Done |
| Basic blocks, if/else, while back edges, for, nesting, return termination | Done - covered by unit tests |
| Graph interactive; node and edge inspection | Done - browser check |
| Metrics calculated correctly | Done - hand-verified values + cross-checks in tests |
| Export (PNG, SVG, JSON) | Done - files opened and parsed in the browser check |
| Tests pass | Done - 106/106 and 44/44 |
| Documentation matches behaviour | Reviewed; claims in PROJECT_LIMITATIONS.md were spot-checked against the engine |
| No fake results / secrets | None used |
| ZIP contains all files; extracts and runs | Verified on **Linux** (fresh venv). **Windows and run.bat were NOT tested** |

## Known issues and limitations

* **`run.bat` has not been executed on Windows** (no Windows system was available). It uses only standard cmd features (py/python detection, venv, pip, fc). If it fails, use the manual steps in the README.
* Python versions other than 3.12 and operating systems other than Linux were not tested.
* Visual quality was checked in headless Chromium at 1500x900, 1366x768 and 390x844 only; other browsers (Edge, Firefox, Safari) were not tested. Edge is Chromium-based and should behave the same.
* Back-edge curves are routed by a simple heuristic; on dense graphs an edge can pass close to a node or labels can overlap. Zoom and the layout selector help.
* SVG export approximates the on-screen curves; PNG export is the on-screen canvas.
* Language and analysis limits are listed in PROJECT_LIMITATIONS.md (no semantic analysis, `&&`/`||` not split, only literal constants folded, jump threading).
* Flask development server only.
* REPORT.md is a draft with placeholders for the student (university ID, guide, date, declaration). References were written without library access and must be double-checked.

## Exact run instructions (Windows)

1. Install Python 3.10+ (tick "Add python.exe to PATH").
2. Extract CFG-Generator.zip. Double-click `run.bat`.
3. Open http://127.0.0.1:5000 in a browser. Stop with Ctrl+C.

Manual: `python -m venv .venv` -> `.venv\Scripts\activate` -> `python -m pip install -r requirements.txt` -> `python app.py`.
