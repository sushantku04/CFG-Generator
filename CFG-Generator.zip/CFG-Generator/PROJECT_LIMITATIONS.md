# Project limitations - what is and is not supported

CFG Studio analyses a **small C-like subset**. It does not claim C compatibility. Anything outside the subset is rejected with an
explanatory message (or, for `#` lines, skipped with a visible warning); nothing is silently ignored.

## Supported

| Area | Supported |
|---|---|
| Program | exactly one function: `int main()` or `int main(void)` |
| Types / declarations | `int` only; several declarators per statement; optional initialiser (`int a = 1, b;`); `for (int i = 0; ...)` |
| Statements | assignment (`= += -= *= /= %=`), `x++` / `x--` (as statements), `if`, `if-else`, `else if`, `while`, `for`, `return`, `return expr;`, `break`, `continue`, `{ }` blocks (nested), empty statement `;` |
| `for` | init, condition and update are each optional; omitted condition = unconditional loop |
| Expressions | integer literals, variables, `( )`, unary `-` `!`, `* / %`, `+ -`, `< <= > >=`, `== !=`, `&&`, `||` with C precedence and left associativity |
| Misc | `//` and `/* */` comments; `#...` lines skipped with a warning; Windows/Unix line endings |
| Analysis | basic blocks (leader method), CFG, reachability, dominators, loop back edges, cyclomatic complexity, validation |

## Not supported (reported as errors)

| Construct | Reported as |
|---|---|
| Functions other than `main`, any function call (`printf`, `scanf`, ...) | unsupported - function calls |
| Types other than `int` (`float`, `double`, `char`, `long`, `unsigned`, `struct`, `enum`, `typedef`, ...) and storage qualifiers (`const`, `static`, ...) | unsupported - only `int` |
| Floating-point literals, string and character literals | unsupported |
| Arrays, pointers, `&` address-of, member access `.` | unsupported |
| `switch` / `case` / `default`, `do-while`, `goto`, labels | unsupported |
| Ternary `?:`, bitwise operators (`& \| ^ ~ << >>`), unary `+`, `++`/`--` inside expressions, comma operator, chained assignment (`a = b = 1`), expression statements (`x + 1;`) | unsupported or syntax error |
| `break` / `continue` outside a loop | semantic error |
| Input > 20,000 characters, > 1,000 lines, nesting depth > 40 | limit error |

## Deliberate simplifications (they affect results)

1. **No semantic analysis.** Undeclared or unused variables, redeclarations, scopes, types, division by zero and a missing `return` are *not* checked.
2. **Conditions are single decisions.** `a && b` produces one decision node, not the two a real compiler produces from short-circuit evaluation. Cyclomatic complexity counts each `if`/`while`/`for` once.
3. **Only integer-literal conditions are folded** (`if (0)`, `while (1)`, `!1`). Expressions such as `2 > 1` or a variable that is always true are *not* evaluated, so the graph keeps both branches.
4. **Jump threading.** Compiler-generated jump-only blocks are removed from the displayed graph (the IR tab shows the raw leaders). Basic-block counts therefore follow this documented rule rather than the purest leader count.
5. **Cyclomatic complexity** is computed on the part of the graph reachable from `ENTRY`. For programs with no reachable exit (infinite loops) the value is one higher than "decisions + 1"; the UI labels this.
6. **No data-flow analysis** (definitions, liveness, dominance frontiers, SSA), no optimisation, no code generation.
7. The graph layout is automatic (dagre) with simple curve routing; very large graphs (hundreds of blocks) are legible only after zooming, and edge labels can overlap on dense graphs.
8. **SVG export** redraws the graph from the same node positions with the same colours; curves are approximations of the on-screen curves. PNG export is a rendering of the on-screen canvas.
9. Development server only (`python app.py`, Flask dev server on 127.0.0.1).
10. Tested on Linux with Python 3.12 and headless Chromium. `run.bat` and Windows were **not** executed by the author of this build (see BUILD_REPORT.md).

## Possible extensions

Short-circuit expansion of `&&`/`||`, `switch` and `do-while`, multiple functions with a call graph, reaching-definitions and live-variable analysis on the CFG, dominator tree view, DOT export, step-through execution trace (would need a safe interpreter).
