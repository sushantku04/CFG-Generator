"""Graph analysis: reachability, dominators, loops, metrics and validation."""

from .cfg import CFG


def adjacency(cfg):
    succ = {n.id: [] for n in cfg.nodes}
    pred = {n.id: [] for n in cfg.nodes}
    for e in cfg.edges:
        succ[e.source].append(e.target)
        pred[e.target].append(e.source)
    return succ, pred


def reachable(cfg, succ=None, start="ENTRY"):
    succ = succ or adjacency(cfg)[0]
    seen, stack = {start}, [start]
    while stack:
        u = stack.pop()
        for v in succ[u]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return seen


def dominators(cfg, reach):
    """Iterative dominator computation on the reachable subgraph."""
    succ, pred = adjacency(cfg)
    order = [n.id for n in cfg.nodes if n.id in reach]
    dom = {n: set(order) for n in order}
    dom["ENTRY"] = {"ENTRY"}
    changed = True
    while changed:
        changed = False
        for n in order:
            if n == "ENTRY":
                continue
            ps = [p for p in pred[n] if p in reach]
            new = set(order)
            for p in ps:
                new &= dom[p]
            new |= {n}
            if new != dom[n]:
                dom[n] = new
                changed = True
    return dom


def mark_back_edges(cfg, reach, dom):
    """An edge u -> v is a loop back edge when v dominates u."""
    for e in cfg.edges:
        e.is_back = e.source in reach and e.target in reach and e.target in dom[e.source]
        if e.is_back and e.kind != "entry" and e.label == "":
            e.label = "back edge"


def components(node_ids, edges):
    parent = {n: n for n in node_ids}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for e in edges:
        if e.source in parent and e.target in parent:
            parent[find(e.source)] = find(e.target)
    return len({find(n) for n in node_ids})


def compute_metrics(cfg, reach):
    nodes = {n.id: n for n in cfg.nodes}
    blocks = [n for n in cfg.nodes if n.type in ("block", "decision")]
    decisions = [n for n in cfg.nodes if n.type == "decision"]
    r_nodes = [n for n in cfg.nodes if n.id in reach]
    r_edges = [e for e in cfg.edges if e.source in reach and e.target in reach]
    P = components([n.id for n in r_nodes], r_edges)
    m_graph = len(r_edges) - len(r_nodes) + 2 * P
    r_decisions = [n for n in decisions if n.id in reach]
    m_pred = len(r_decisions) + 1
    exit_reachable = "EXIT" in reach
    unreachable = [n for n in cfg.nodes if n.id not in reach]
    back_edges = [e for e in cfg.edges if e.is_back]

    if m_graph == m_pred:
        note = "Both conventions agree."
    elif not exit_reachable:
        note = ("EXIT is unreachable (the program never terminates normally), so E - N + 2P is "
                "computed without the exit edge and exceeds 'decisions + 1'.")
    else:
        note = "The two conventions differ for this graph (see the convention text)."

    return {
        "basicBlocks": len(blocks),
        "decisionNodes": len(decisions),
        "cfgNodes": len(cfg.nodes),
        "cfgEdges": len(cfg.edges),
        "reachableNodes": len(r_nodes),
        "unreachableNodes": len(unreachable),
        "loopBackEdges": len(back_edges),
        "connectedComponents": P,
        "cyclomaticComplexity": m_graph,
        "cyclomaticPredicateBased": m_pred,
        "conventionsAgree": m_graph == m_pred,
        "conventionNote": note,
        "exitReachable": exit_reachable,
        "convention": (
            "M = E - N + 2P, computed on the subgraph reachable from ENTRY (unreachable code "
            "does not add independent paths). Synthetic ENTRY and EXIT nodes are counted as "
            "nodes; their edges are counted as edges. Each if/while/for condition is one "
            "decision (&& and || are not counted separately). Cross-check: decisions + 1."),
    }


VALID_LABELS = {"", "True", "False", "return", "break", "continue", "back edge"}


def validate(cfg, reach=None):
    """Structural checks. Reports only what is actually verified."""
    checks = []

    def check(name, ok, detail=""):
        checks.append({"name": name, "passed": bool(ok), "detail": "" if ok else detail})

    succ_e = {n.id: [] for n in cfg.nodes}
    pred_e = {n.id: [] for n in cfg.nodes}
    ids = [n.id for n in cfg.nodes]
    check("Node IDs are unique", len(ids) == len(set(ids)), "duplicate node id")
    eids = [e.id for e in cfg.edges]
    check("Edge IDs are unique", len(eids) == len(set(eids)), "duplicate edge id")
    valid_ends = all(e.source in succ_e and e.target in succ_e for e in cfg.edges)
    check("All edge endpoints exist", valid_ends, "edge refers to a missing node")
    if not valid_ends:
        return {"passed": False, "checks": checks}
    for e in cfg.edges:
        succ_e[e.source].append(e)
        pred_e[e.target].append(e)
    check("Edge labels are valid", all(e.label in VALID_LABELS for e in cfg.edges), "unknown edge label")
    check("No duplicate edges (same source, target and label)",
          len({(e.source, e.target, e.label) for e in cfg.edges}) == len(cfg.edges), "duplicate edge")
    check("ENTRY has no incoming edge and exactly one outgoing edge",
          not pred_e["ENTRY"] and len(succ_e["ENTRY"]) == 1, "bad ENTRY edges")
    check("EXIT has no outgoing edges", not succ_e["EXIT"], "EXIT has successors")

    bad = []
    for n in cfg.nodes:
        outs = succ_e[n.id]
        if n.type == "decision":
            if sorted(e.label for e in outs) != ["False", "True"]:
                bad.append(f"{n.id}: decision must have exactly one True and one False edge")
        elif n.type == "block":
            if len(outs) != 1 or outs[0].label in ("True", "False"):
                bad.append(f"{n.id}: non-decision block must have exactly one unlabelled-branch successor")
            elif n.terminator == "return" and (outs[0].target != "EXIT" or outs[0].label != "return"):
                bad.append(f"{n.id}: a return block must go only to EXIT")
    check("Decision nodes have exactly True and False successors; other blocks have one successor; "
          "return blocks go only to EXIT", not bad, "; ".join(bad))

    if reach is None:
        reach = reachable(cfg)
    check("ENTRY is reachable (reachability computed)", "ENTRY" in reach)
    return {"passed": all(c["passed"] for c in checks), "checks": checks}
