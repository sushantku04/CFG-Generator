"""AST node types for the supported C subset, plus an expression printer."""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple


# ---------------------------------------------------------------- expressions
@dataclass
class Num:
    value: int


@dataclass
class Var:
    name: str


@dataclass
class Unary:
    op: str
    operand: object


@dataclass
class Binary:
    op: str
    left: object
    right: object


@dataclass
class Paren:
    inner: object


# ----------------------------------------------------------------- statements
@dataclass
class Decl:
    declarators: List[Tuple[str, Optional[object]]]
    line: int = 0


@dataclass
class Assign:
    target: str
    op: str
    value: object
    line: int = 0


@dataclass
class IncDec:
    target: str
    op: str
    line: int = 0


@dataclass
class If:
    cond: object
    then: object
    otherwise: Optional[object]
    line: int = 0


@dataclass
class While:
    cond: object
    body: object
    line: int = 0


@dataclass
class For:
    init: Optional[object]
    cond: Optional[object]
    update: Optional[object]
    body: object
    line: int = 0


@dataclass
class Return:
    value: Optional[object]
    line: int = 0


@dataclass
class Break:
    line: int = 0


@dataclass
class Continue:
    line: int = 0


@dataclass
class Empty:
    line: int = 0


@dataclass
class Block:
    stmts: List[object] = field(default_factory=list)
    line: int = 0
    end_line: int = 0


@dataclass
class Program:
    body: Block
    line: int = 1


# ------------------------------------------------------------------- printing
def expr_to_str(e):
    """Render an expression with normalised spacing (parentheses are preserved)."""
    if isinstance(e, Num):
        return str(e.value)
    if isinstance(e, Var):
        return e.name
    if isinstance(e, Paren):
        return "(" + expr_to_str(e.inner) + ")"
    if isinstance(e, Unary):
        return e.op + expr_to_str(e.operand)
    if isinstance(e, Binary):
        return f"{expr_to_str(e.left)} {e.op} {expr_to_str(e.right)}"
    raise TypeError(f"not an expression: {e!r}")


def simple_stmt_to_str(s):
    """Text of a simple (non-control-flow) statement, as shown inside basic blocks."""
    if isinstance(s, Decl):
        parts = []
        for name, init in s.declarators:
            parts.append(name if init is None else f"{name} = {expr_to_str(init)}")
        return "int " + ", ".join(parts) + ";"
    if isinstance(s, Assign):
        return f"{s.target} {s.op} {expr_to_str(s.value)};"
    if isinstance(s, IncDec):
        return f"{s.target}{s.op};"
    raise TypeError(f"not a simple statement: {s!r}")
