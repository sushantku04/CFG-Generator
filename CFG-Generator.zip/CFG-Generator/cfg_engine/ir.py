"""Lowering: AST -> linear, label-based structured IR.

Every control-flow statement is flattened into a list of instructions with
explicit jumps. This is what the leader algorithm (cfg.py) works on.

Instruction kinds
    stmt    a simple statement (declaration / assignment / ++ / --)
    branch  conditional jump: goes to true_label if cond holds, else false_label
    jump    unconditional jump to a label
    return  leaves the function
"""

from dataclasses import dataclass
from typing import Optional

from . import ast_nodes as A
from .errors import CFGError


@dataclass
class Instr:
    kind: str
    text: str = ""
    line: int = 0
    true_label: Optional[int] = None
    false_label: Optional[int] = None
    target: Optional[int] = None
    reason: str = ""          # why a jump exists: loop-back, break, continue, if-end, constant-false
    synthetic: bool = False   # compiler-generated jump with no source text of its own
    note: str = ""


def _const_truth(e):
    """Truth value of a constant condition (integer literal, !, unary -, parentheses), else None."""
    if isinstance(e, A.Num):
        return e.value != 0
    if isinstance(e, A.Paren):
        return _const_truth(e.inner)
    if isinstance(e, A.Unary):
        inner = _const_truth(e.operand)
        if inner is None:
            return None
        if e.op == "!":
            return not inner
        if e.op == "-":
            return inner
    return None


class Lowerer:
    def __init__(self):
        self.instrs = []
        self.label_pos = {}
        self.warnings = []
        self._next_label = 0
        self._loops = []  # stack of (break_label, continue_label)

    # -- helpers
    def new_label(self):
        self._next_label += 1
        return self._next_label

    def place(self, label):
        self.label_pos[label] = len(self.instrs)

    def emit(self, **kw):
        self.instrs.append(Instr(**kw))

    def jump(self, label, line, reason, synthetic=True, note=""):
        self.emit(kind="jump", target=label, line=line, reason=reason, synthetic=synthetic, note=note)

    def cond(self, expr, true_l, false_l, line, what):
        """Emit the branch for a condition. true_l must be placed immediately afterwards."""
        text = A.expr_to_str(expr)
        c = _const_truth(expr)
        if c is True:
            self.warnings.append({
                "line": line,
                "message": f"Condition of '{what}' ({text}) is a constant true: "
                           f"no branch is generated, the body always executes."})
        elif c is False:
            self.warnings.append({
                "line": line,
                "message": f"Condition of '{what}' ({text}) is a constant false: "
                           f"the body can never execute."})
            self.jump(false_l, line, "constant-false", synthetic=False,
                      note=f"{what} condition '{text}' is constant false - always jumps past the body")
        else:
            self.emit(kind="branch", text=text, line=line, true_label=true_l, false_label=false_l)

    # -- statements
    def lower(self, s):
        if isinstance(s, A.Block):
            for x in s.stmts:
                self.lower(x)
        elif isinstance(s, (A.Decl, A.Assign, A.IncDec)):
            self.emit(kind="stmt", text=A.simple_stmt_to_str(s), line=s.line)
        elif isinstance(s, A.Empty):
            pass  # no code: an empty statement generates no instruction
        elif isinstance(s, A.Return):
            text = "return;" if s.value is None else f"return {A.expr_to_str(s.value)};"
            self.emit(kind="return", text=text, line=s.line)
        elif isinstance(s, A.If):
            self._if(s)
        elif isinstance(s, A.While):
            self._while(s)
        elif isinstance(s, A.For):
            self._for(s)
        elif isinstance(s, A.Break):
            if not self._loops:
                raise CFGError("semantic", "'break' statement not within a loop.", s.line)
            self.jump(self._loops[-1][0], s.line, "break", synthetic=False)
        elif isinstance(s, A.Continue):
            if not self._loops:
                raise CFGError("semantic", "'continue' statement not within a loop.", s.line)
            self.jump(self._loops[-1][1], s.line, "continue", synthetic=False)
        else:  # pragma: no cover
            raise CFGError("internal", f"Unhandled statement type {type(s).__name__}")

    def _if(self, s):
        then_l, else_l, end_l = self.new_label(), self.new_label(), self.new_label()
        has_else = s.otherwise is not None
        self.cond(s.cond, then_l, else_l if has_else else end_l, s.line, "if")
        self.place(then_l)
        self.lower(s.then)
        if has_else:
            self.jump(end_l, s.line, "if-end")
            self.place(else_l)
            self.lower(s.otherwise)
        self.place(end_l)

    def _while(self, s):
        cond_l, body_l, end_l = self.new_label(), self.new_label(), self.new_label()
        self.place(cond_l)
        self.cond(s.cond, body_l, end_l, s.line, "while")
        self.place(body_l)
        self._loops.append((end_l, cond_l))
        self.lower(s.body)
        self._loops.pop()
        self.jump(cond_l, s.line, "loop-back")
        self.place(end_l)

    def _for(self, s):
        if s.init is not None:
            self.lower(s.init)
        cond_l, body_l, upd_l, end_l = (self.new_label() for _ in range(4))
        self.place(cond_l)
        if s.cond is not None:
            self.cond(s.cond, body_l, end_l, s.line, "for")
        # an omitted condition means 'always true': cond_l and body_l coincide
        self.place(body_l)
        self._loops.append((end_l, upd_l))
        self.lower(s.body)
        self._loops.pop()
        self.place(upd_l)
        if s.update is not None:
            self.lower(s.update)
        self.jump(cond_l, s.line, "loop-back")
        self.place(end_l)


def lower_program(program):
    """Lower a Program AST. Returns (instrs, label_pos, warnings)."""
    lw = Lowerer()
    lw.lower(program.body)
    return lw.instrs, lw.label_pos, lw.warnings
