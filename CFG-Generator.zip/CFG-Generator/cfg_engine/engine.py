"""Pipeline orchestration: source -> AST -> IR -> leaders -> blocks -> CFG -> metrics -> JSON."""

from . import analysis
from .cfg import build_cfg
from .errors import CFGError
from .ir import lower_program
from .parser import parse_source


def _label(node):
    return node.id


def analyze_source(code):
    """Analyse source text. Returns the JSON-serialisable success payload or raises CFGError."""
    try:
        program, _cleaned, warnings = parse_source(code)
        instrs, label_pos, ir_warnings = lower_program(program)
        warnings = list(warnings) + list(ir_warnings)
        cfg = build_cfg(instrs, label_pos)
    except CFGError:
        raise
    except RecursionError:
        raise CFGError("limit", "The program is nested too deeply to analyse.")
    except Exception:  # never leak internals to the client
        raise CFGError("internal", "Internal error while building the CFG.")

    succ, _pred = analysis.adjacency(cfg)
    reach = analysis.reachable(cfg, succ)
    dom = analysis.dominators(cfg, reach)
    analysis.mark_back_edges(cfg, reach, dom)
    validation = analysis.validate(cfg, reach)
    if not validation["passed"]:
        failed = [c["name"] for c in validation["checks"] if not c["passed"]]
        raise CFGError("internal", "CFG validation failed: " + "; ".join(failed))
    metrics = analysis.compute_metrics(cfg, reach)

    unreachable = []
    for n in cfg.nodes:
        if n.id in reach:
            continue
        if n.id == "EXIT":
            warnings.append({"line": None, "message":
                             "EXIT is unreachable: no execution path leaves main normally (infinite loop)."})
        else:
            unreachable.append({"id": n.id, "lines": n.lines})
            where = ("line " + ", ".join(map(str, n.lines))) if n.lines else "no source lines"
            warnings.append({"line": n.lines[0] if n.lines else None,
                             "message": f"Block {n.id} ({where}) is unreachable."})

    nodes = []
    for n in cfg.nodes:
        nodes.append({
            "id": n.id,
            "type": n.type,
            "statements": n.statements,
            "condition": n.condition,
            "lines": n.lines,
            "terminator": n.terminator,
            "note": n.note,
            "reachable": n.id in reach,
        })
    edges = [{
        "id": e.id, "source": e.source, "target": e.target, "label": e.label,
        "kind": e.kind, "isBack": e.is_back,
        "reachable": e.source in reach,
    } for e in cfg.edges]

    leader_set = set(cfg.leaders)
    ir_rows = []
    for i, ins in enumerate(cfg.instrs):
        if ins.kind == "branch":
            text = f"if {ins.text} goto L{label_pos_name(label_pos, ins.true_label)} else goto L{label_pos_name(label_pos, ins.false_label)}"
        elif ins.kind == "jump":
            text = f"goto L{label_pos_name(label_pos, ins.target)}"
        else:
            text = ins.text
        ir_rows.append({
            "index": i, "kind": ins.kind, "text": text, "line": ins.line,
            "isLeader": i in leader_set, "block": cfg.block_of_instr.get(i),
            "synthetic": ins.synthetic,
        })

    loops = {}
    for e in cfg.edges:
        if e.is_back:
            loops.setdefault(e.target, []).append(e.id)

    return {
        "success": True,
        "graph": {"nodes": nodes, "edges": edges},
        "metrics": metrics,
        "warnings": warnings,
        "analysis": {
            "validation": validation,
            "unreachable": unreachable,
            "loops": [{"header": h, "backEdges": b} for h, b in loops.items()],
            "leaders": sorted(cfg.leaders),
            "ir": ir_rows,
            "stages": ["parse (Lark LALR)", "AST", "structured IR", "leaders", "basic blocks",
                       "CFG edges", "dominators / back edges", "metrics", "validation"],
        },
    }


def label_pos_name(label_pos, label):
    """Name a jump target by the instruction index it points to (readable IR)."""
    return label_pos[label]
