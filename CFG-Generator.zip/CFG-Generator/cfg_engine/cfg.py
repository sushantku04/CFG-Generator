"""Basic blocks (leader algorithm) and CFG construction."""

from dataclasses import dataclass, field
from typing import List, Optional

ENTRY, EXIT = "entry", "exit"


@dataclass
class Block:
    index: int          # position among blocks (0-based, provisional)
    start: int          # first instruction index
    end: int            # one past the last instruction index
    instrs: list = field(default_factory=list)


@dataclass
class Node:
    id: str
    type: str                       # entry | exit | block | decision
    statements: List[dict] = field(default_factory=list)
    condition: Optional[dict] = None
    lines: List[int] = field(default_factory=list)
    terminator: str = "none"        # branch | return | jump | fallthrough | none
    note: str = ""


@dataclass
class Edge:
    id: str
    source: str
    target: str
    label: str = ""
    kind: str = "sequential"        # entry | sequential | jump | true | false | return
    is_back: bool = False


@dataclass
class CFG:
    nodes: List[Node]
    edges: List[Edge]
    leaders: List[int]
    instrs: list
    block_of_instr: dict            # instr index -> final node id


# ------------------------------------------------------------- leader method
def find_leaders(instrs, label_pos):
    """Leader algorithm.

    A leader is the first instruction of a basic block:
      1. the first instruction of the function;
      2. any instruction that is the target of a jump or branch;
      3. any instruction that immediately follows a jump, branch or return.
    """
    n = len(instrs)
    leaders = set()
    if n:
        leaders.add(0)
    for i, ins in enumerate(instrs):
        targets = []
        if ins.kind == "jump":
            targets = [ins.target]
        elif ins.kind == "branch":
            targets = [ins.true_label, ins.false_label]
        for t in targets:
            pos = label_pos[t]
            if pos < n:
                leaders.add(pos)
        if ins.kind in ("jump", "branch", "return") and i + 1 < n:
            leaders.add(i + 1)
    return sorted(leaders)


def form_blocks(instrs, leaders):
    """Group instructions from each leader up to (not including) the next leader."""
    blocks = []
    bounds = leaders + [len(instrs)]
    for k, start in enumerate(leaders):
        blocks.append(Block(index=k, start=start, end=bounds[k + 1], instrs=instrs[start:bounds[k + 1]]))
    return blocks


# --------------------------------------------------------------- CFG building
def _successors(block, blocks, block_at, label_pos, n):
    """Outgoing edges of a block as (target, label, kind); target is a block index or EXIT."""

    def tgt(label):
        pos = label_pos[label]
        return EXIT if pos >= n else block_at[pos]

    last = block.instrs[-1]
    if last.kind == "branch":
        return [(tgt(last.true_label), "True", "true"), (tgt(last.false_label), "False", "false")]
    if last.kind == "jump":
        label = {"break": "break", "continue": "continue"}.get(last.reason, "")
        return [(tgt(last.target), label, "jump")]
    if last.kind == "return":
        return [(EXIT, "return", "return")]
    nxt = block.index + 1
    return [(nxt if nxt < len(blocks) else EXIT, "", "sequential")]


def _thread_jump_only_blocks(blocks, succ):
    """Cleanup after block formation ("jump threading").

    The leader method puts every jump target in its own block, which can leave blocks that
    contain nothing except a compiler-generated jump (the join after an if-else inside a
    loop, an empty loop body, a dead loop-back jump ...). Such a block corresponds to no
    source statement, so edges into it are redirected to its successor and the block is
    removed. Blocks that hold user-written jumps (break / continue) are never removed.
    A cycle made only of such blocks (e.g. `while (1) { }`) is kept: it is the loop.
    """
    thread = {b.index for b in blocks
              if len(b.instrs) == 1 and b.instrs[0].kind == "jump" and b.instrs[0].synthetic}

    def raw(t):
        return succ[t][0][0]

    keep = set()
    for s0 in sorted(thread):
        seen, cur = [], s0
        while cur != EXIT and cur in thread and cur not in keep and cur not in seen:
            seen.append(cur)
            cur = raw(cur)
        if cur in seen:
            keep.update(seen[seen.index(cur):])
    thread -= keep

    def resolve(t):
        while t != EXIT and t in thread:
            t = raw(t)
        return t

    return thread, resolve


def build_cfg(instrs, label_pos):
    n = len(instrs)
    leaders = find_leaders(instrs, label_pos)
    blocks = form_blocks(instrs, leaders)
    block_at = {}
    for b in blocks:
        for i in range(b.start, b.end):
            block_at[i] = b.index

    succ = {b.index: _successors(b, blocks, block_at, label_pos, n) for b in blocks}
    threaded, resolve = _thread_jump_only_blocks(blocks, succ)
    kept = [b for b in blocks if b.index not in threaded]
    first = resolve(0) if blocks else EXIT

    ids = {b.index: f"B{k + 1}" for k, b in enumerate(kept)}
    nodes = [Node(id="ENTRY", type=ENTRY, terminator="fallthrough", note="Synthetic entry node")]
    for b in kept:
        stmts, cond = [], None
        for ins in b.instrs:
            if ins.kind in ("stmt", "return"):
                stmts.append({"text": ins.text, "line": ins.line})
            elif ins.kind == "branch":
                cond = {"text": ins.text, "line": ins.line}
        last = b.instrs[-1]
        if last.kind == "jump" and last.reason in ("break", "continue"):
            stmts.append({"text": f"{last.reason};", "line": last.line})   # source code the user wrote
        term = {"branch": "branch", "jump": "jump", "return": "return"}.get(last.kind, "fallthrough")
        node = Node(
            id=ids[b.index],
            type="decision" if last.kind == "branch" else "block",
            statements=stmts,
            condition=cond,
            terminator=term,
            note=last.note if last.kind == "jump" else "",
        )
        if last.kind == "jump" and not last.note and not stmts and last.synthetic:
            node.note = f"No statements - compiler-generated jump ({last.reason}); this is an empty loop."
        ln = [s["line"] for s in stmts] + ([cond["line"]] if cond else [])
        if last.kind == "jump" and last.reason == "constant-false":
            ln.append(last.line)
        node.lines = sorted(set(x for x in ln if x))
        nodes.append(node)
    nodes.append(Node(id="EXIT", type=EXIT, terminator="none", note="Synthetic exit node"))

    def nid(t):
        return "EXIT" if t == EXIT else ids[t]

    edges = []

    def add(src, dst, label, kind):
        edges.append(Edge(id=f"E{len(edges) + 1}", source=src, target=dst, label=label, kind=kind))

    add("ENTRY", nid(first), "", "entry")
    for b in kept:
        for t, label, kind in succ[b.index]:
            add(ids[b.index], nid(resolve(t)), label, kind)

    block_of_instr = {i: ids[b.index] for b in kept for i in range(b.start, b.end)}
    return CFG(nodes=nodes, edges=edges, leaders=leaders, instrs=instrs, block_of_instr=block_of_instr)
