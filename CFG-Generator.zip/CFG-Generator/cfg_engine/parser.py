"""Front end: pre-checks, Lark parsing and AST construction.

Pipeline for this stage:
    source text --precheck--> cleaned text --Lark LALR(1)--> parse tree --ToAST--> AST
Every failure is converted into a CFGError with a readable message and, where
Lark provides it, a line and column.
"""

import re
from pathlib import Path

from lark import Lark, Transformer, v_args
from lark.exceptions import (
    LarkError,
    UnexpectedCharacters,
    UnexpectedEOF,
    UnexpectedToken,
    VisitError,
)

from . import ast_nodes as A
from .errors import CFGError

MAX_CODE_LENGTH = 20000
MAX_LINES = 1000
MAX_NESTING = 40

_GRAMMAR_FILE = Path(__file__).with_name("grammar.lark")

_PARSER = Lark(
    _GRAMMAR_FILE.read_text(encoding="utf-8"),
    parser="lalr",
    lexer="contextual",
    propagate_positions=True,
    maybe_placeholders=True,
)

# ------------------------------------------------------------ unsupported words
_UNSUPPORTED_STATEMENTS = {
    "do": "'do-while' loops are not supported (use 'while' or 'for')",
    "switch": "'switch' statements are not supported (use if / else if)",
    "case": "'case' labels are not supported (no 'switch' in this subset)",
    "default": "'default' labels are not supported (no 'switch' in this subset)",
    "goto": "'goto' is not supported",
}
_UNSUPPORTED_TYPES = {
    "float", "double", "char", "long", "short", "unsigned", "signed", "bool",
    "_Bool", "struct", "union", "enum", "typedef", "const", "static", "extern",
    "register", "volatile", "auto", "inline", "sizeof",
}
_CALL_ALLOWED_BEFORE_PAREN = {"if", "while", "for", "return", "main", "int", "void"}

_UNSUPPORTED_CHARS = {
    '"': "string literals are not supported",
    "'": "character literals are not supported",
    "[": "arrays are not supported",
    "]": "arrays are not supported",
    ".": "floating-point numbers and member access are not supported",
    "?": "the ternary operator '?:' is not supported",
    ":": "the ternary operator '?:' / labels are not supported",
    "&": "'&' (bitwise AND / address-of) is not supported - did you mean '&&'?",
    "|": "'|' (bitwise OR) is not supported - did you mean '||'?",
    "^": "bitwise operators are not supported",
    "~": "bitwise operators are not supported",
    "@": "'@' is not valid C",
    "$": "'$' is not valid in this subset",
    "`": "'`' is not valid C",
}

_TERMINAL_NAMES = {
    "NAME": "an identifier",
    "NUMBER": "a number",
    "OR": "'||'",
    "AND": "'&&'",
    "EQOP": "'==' or '!='",
    "RELOP": "a relational operator (<, <=, >, >=)",
    "ADDOP": "'+' or '-'",
    "MULOP": "'*', '/' or '%'",
    "UNOP": "'!' or '-'",
    "INCDEC": "'++' or '--'",
    "$END": "end of file",
}


def _terminal_display():
    names = dict(_TERMINAL_NAMES)
    for t in _PARSER.terminals:
        if t.name not in names:
            pat = t.pattern
            if pat.type == "str":
                names[t.name] = "'" + pat.value + "'"
    return names


_DISPLAY = _terminal_display()


# ----------------------------------------------------------------- pre-checks
def precheck(code):
    """Validate size/nesting, handle comments and preprocessor lines.

    Returns (cleaned_code, warnings). Preprocessor lines (#include ...) are blanked
    out - keeping line numbers intact - and reported as warnings; they are never
    silently dropped.
    """
    if not isinstance(code, str):
        raise CFGError("input", "Source code must be text.")
    code = code.replace("\r\n", "\n").replace("\r", "\n")
    if not code.strip():
        raise CFGError("input", "The editor is empty. Enter a program like: int main() { ... }")
    if len(code) > MAX_CODE_LENGTH:
        raise CFGError("limit", f"Input is too long ({len(code)} characters). Limit: {MAX_CODE_LENGTH}.")
    if code.count("\n") + 1 > MAX_LINES:
        raise CFGError("limit", f"Input has too many lines. Limit: {MAX_LINES}.")
    if "\x00" in code:
        raise CFGError("input", "Source code contains a NUL character.")

    warnings = []
    out = []
    depth = 0
    max_depth = 0
    i, n = 0, len(code)
    line, col = 1, 1
    line_start = True
    in_block_comment = None  # (line, col) where it opened
    while i < n:
        ch = code[i]
        nxt = code[i + 1] if i + 1 < n else ""
        if in_block_comment:
            if ch == "*" and nxt == "/":
                in_block_comment = None
                out.append("*/")
                i += 2
                col += 2
                continue
            out.append(ch)
            if ch == "\n":
                line += 1
                col = 1
                line_start = True
            else:
                col += 1
            i += 1
            continue
        if ch == "/" and nxt == "*":
            in_block_comment = (line, col)
            out.append("/*")
            i += 2
            col += 2
            continue
        if ch == "/" and nxt == "/":
            j = code.find("\n", i)
            j = n if j == -1 else j
            out.append(code[i:j])
            col += j - i
            i = j
            continue
        if ch == "#" and line_start:
            j = code.find("\n", i)
            j = n if j == -1 else j
            directive = code[i:j].strip()
            warnings.append({
                "line": line,
                "message": f"Preprocessor directive '{directive}' was ignored "
                           f"(not part of the supported subset).",
            })
            out.append(" " * (j - i))
            col += j - i
            i = j
            continue
        if ch in "({":
            depth += 1
            max_depth = max(max_depth, depth)
        elif ch in ")}":
            depth = max(0, depth - 1)
        if ch == "\n":
            line += 1
            col = 1
            line_start = True
        else:
            if not ch.isspace():
                line_start = False
            col += 1
        out.append(ch)
        i += 1
    if in_block_comment:
        raise CFGError("lexical", "Unterminated block comment ('/*' without matching '*/').",
                       line=in_block_comment[0], column=in_block_comment[1])
    if max_depth > MAX_NESTING:
        raise CFGError("limit", f"Nesting is too deep ({max_depth} levels). Limit: {MAX_NESTING}.")
    return "".join(out), warnings


def _strip_comments(code):
    """Blank out comments (keeping offsets) so keyword scanning ignores them."""
    def blank(m):
        return re.sub(r"[^\n]", " ", m.group(0))
    return re.sub(r"//[^\n]*|/\*[\s\S]*?\*/", blank, code)


def _line_col(text, pos):
    line = text.count("\n", 0, pos) + 1
    col = pos - (text.rfind("\n", 0, pos) + 1) + 1
    return line, col


def _find_unsupported(code):
    """Return a CFGError for the first unsupported keyword / function call, or None."""
    text = _strip_comments(code)
    for m in re.finditer(r"[A-Za-z_][A-Za-z0-9_]*", text):
        word = m.group(0)
        line, col = _line_col(text, m.start())
        if word in _UNSUPPORTED_STATEMENTS:
            return CFGError("unsupported", _UNSUPPORTED_STATEMENTS[word], line, col)
        if word in _UNSUPPORTED_TYPES:
            return CFGError(
                "unsupported",
                f"'{word}' is not supported - only the 'int' type is available in this subset.",
                line, col)
        if word not in _CALL_ALLOWED_BEFORE_PAREN:
            rest = text[m.end():].lstrip()
            if rest.startswith("("):
                return CFGError(
                    "unsupported",
                    f"Function calls are not supported (found a call to '{word}'). "
                    f"Only a single 'int main()' function is allowed.",
                    line, col)
    return None


# --------------------------------------------------------------- AST builder
@v_args(meta=True)
class ToAST(Transformer):
    def start(self, meta, c):
        return A.Program(body=c[0], line=meta.line)

    def block(self, meta, c):
        return A.Block(stmts=list(c), line=meta.line, end_line=meta.end_line)

    def declarator(self, meta, c):
        return (str(c[0]), c[1])

    def decl(self, meta, c):
        return A.Decl(declarators=list(c), line=meta.line)

    def decl_stmt(self, meta, c):
        return c[0]

    def assign_op(self, meta, c):
        return str(c[0])

    def assign(self, meta, c):
        return A.Assign(target=str(c[0]), op=c[1], value=c[2], line=meta.line)

    def assign_stmt(self, meta, c):
        return c[0]

    def incdec(self, meta, c):
        return A.IncDec(target=str(c[0]), op=str(c[1]), line=meta.line)

    def incdec_stmt(self, meta, c):
        return c[0]

    def if_stmt(self, meta, c):
        return A.If(cond=c[0], then=c[1], otherwise=c[2], line=meta.line)

    def while_stmt(self, meta, c):
        return A.While(cond=c[0], body=c[1], line=meta.line)

    def for_stmt(self, meta, c):
        return A.For(init=c[0], cond=c[1], update=c[2], body=c[3], line=meta.line)

    def return_stmt(self, meta, c):
        return A.Return(value=c[0], line=meta.line)

    def break_stmt(self, meta, c):
        return A.Break(line=meta.line)

    def continue_stmt(self, meta, c):
        return A.Continue(line=meta.line)

    def empty_stmt(self, meta, c):
        return A.Empty(line=meta.line)

    def binop(self, meta, c):
        return A.Binary(op=str(c[1]), left=c[0], right=c[2])

    def unop(self, meta, c):
        return A.Unary(op=str(c[0]), operand=c[1])

    def num(self, meta, c):
        return A.Num(value=int(c[0]))

    def var(self, meta, c):
        return A.Var(name=str(c[0]))

    def paren(self, meta, c):
        return A.Paren(inner=c[0])


# ------------------------------------------------------------ error mapping
def _expected_text(expected):
    names = []
    for e in sorted(expected):
        d = _DISPLAY.get(e)
        if d and d not in names:
            names.append(d)
    if not names:
        return ""
    if len(names) > 6:
        names = names[:6] + ["..."]
    return "Expected " + ", ".join(names) + "."


def _map_lark_error(e, code):
    if isinstance(e, UnexpectedCharacters):
        ch = code[e.pos_in_stream] if e.pos_in_stream is not None and e.pos_in_stream < len(code) else "?"
        if ch in _UNSUPPORTED_CHARS:
            return CFGError("unsupported", f"Unexpected character '{ch}': {_UNSUPPORTED_CHARS[ch]}.",
                            e.line, e.column)
        return CFGError("lexical", f"Unexpected character '{ch}'.", e.line, e.column)
    if isinstance(e, UnexpectedToken):
        tok = e.token
        if tok.type == "$END":
            return CFGError(
                "syntax",
                "Unexpected end of file - the program looks incomplete.",
                getattr(tok, "line", None), getattr(tok, "column", None),
                hint="Check for a missing '}' or ')' or ';'.")
        value = str(tok)
        hint = None
        exp = set(e.expected or [])
        # 'else' with no open 'if' is lexed as an identifier, so the parser only fails on the next token.
        prev = re.search(r"([A-Za-z_][A-Za-z0-9_]*)\s*$", code[:tok.start_pos])
        if prev and prev.group(1) == "else":
            line, col = _line_col(code, prev.start(1))
            return CFGError("syntax", "'else' without a matching 'if'.", line, col)
        if "SEMICOLON" in exp and tok.type != "SEMICOLON":
            # Report where the ';' belongs: right after the previous token (like gcc does).
            p = tok.start_pos - 1
            while p >= 0 and code[p].isspace():
                p -= 1
            if p >= 0:
                line, col = _line_col(code, p + 1)
                return CFGError("syntax", f"Expected ';' before '{value}'.", line, col,
                                hint="A ';' is probably missing at the end of this statement.")
        if value == "else":
            return CFGError("syntax", "'else' without a matching 'if'.", tok.line, tok.column)
        if value == "void":
            return CFGError("syntax", "Expected 'int main()' - the function must return int.",
                            tok.line, tok.column)
        msg = f"Unexpected '{value}'."
        extra = _expected_text(exp)
        if extra:
            msg += " " + extra
        return CFGError("syntax", msg, tok.line, tok.column, hint=hint)
    if isinstance(e, UnexpectedEOF):
        return CFGError("syntax", "Unexpected end of file - the program looks incomplete.",
                        hint="Check for a missing '}' or ')'.")
    return CFGError("syntax", "The program could not be parsed.")


def _pos(err):
    return (err.line or 10 ** 9, err.column or 10 ** 9)


def parse_source(code):
    """Parse source text. Returns (ast.Program, cleaned_code, warnings)."""
    cleaned, warnings = precheck(code)
    unsupported = _find_unsupported(cleaned)
    parse_error = None
    tree = None
    try:
        tree = _PARSER.parse(cleaned)
    except VisitError as ve:  # pragma: no cover - defensive
        raise ve.orig_exc
    except RecursionError:
        raise CFGError("limit", "The program is nested too deeply to analyse.")
    except LarkError as le:
        parse_error = _map_lark_error(le, cleaned)

    if unsupported and (parse_error is None or _pos(unsupported) <= _pos(parse_error)):
        raise unsupported
    if parse_error:
        raise parse_error
    try:
        program = ToAST().transform(tree)
    except VisitError as ve:
        if isinstance(ve.orig_exc, CFGError):
            raise ve.orig_exc
        raise CFGError("internal", "Internal error while building the AST.")
    except RecursionError:
        raise CFGError("limit", "The program is nested too deeply to analyse.")
    return program, cleaned, warnings
