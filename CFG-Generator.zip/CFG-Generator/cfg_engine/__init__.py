"""CFG Studio compiler engine (independent of Flask and the front end)."""

from .engine import analyze_source
from .errors import CFGError

__all__ = ["analyze_source", "CFGError"]
