"""Error type shared by every stage of the compiler engine."""


class CFGError(Exception):
    """A user-facing error produced while analysing source code.

    category is one of: input, lexical, syntax, unsupported, semantic, limit, internal
    """

    def __init__(self, category, message, line=None, column=None, hint=None):
        super().__init__(message)
        self.category = category
        self.message = message
        self.line = line
        self.column = column
        self.hint = hint

    def to_dict(self):
        return {
            "success": False,
            "category": self.category,
            "error": self.message,
            "line": self.line,
            "column": self.column,
            "hint": self.hint,
        }
