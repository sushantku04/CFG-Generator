<!--
  DRAFT REPORT - Compiler Design mini-project (intended length: max 10 pages when formatted).
  Items in [square brackets] must be completed by the student. Nothing here was invented on your behalf:
  no university ID, faculty name, approval or date has been filled in.
  Convert to Word/PDF: open in any Markdown editor, or paste into Word and keep the headings.
-->

# Interactive Control Flow Graph (CFG) Generator

**A Compiler Design Mini-Project**

| | |
|---|---|
| Project title | Interactive Control Flow Graph (CFG) Generator - "CFG Studio" |
| Subject | Compiler Design |
| Student | Sushant Kumar |
| Programme | B.Tech CSE (AI/ML) |
| University | Karnavati University |
| University ID | [STUDENT TO FILL IN] |
| Semester / Section | [STUDENT TO FILL IN] |
| Faculty / Guide | [STUDENT TO FILL IN] |
| Date of submission | [STUDENT TO FILL IN - submission day given by the department] |
| Group members (if any) | [STUDENT TO FILL IN - or write "individual"] |

---

## 1. Abstract

A Control Flow Graph (CFG) shows every path a program may follow during execution and is the basic data structure behind compiler optimisation,
static analysis and testing. This project implements **CFG Studio**, an educational web application that accepts a clearly defined subset of C, validates it
with a Lark LALR(1) grammar, lowers the AST to a structured intermediate representation with explicit jumps, identifies *leaders*, forms *basic blocks*,
builds the CFG, computes metrics (including cyclomatic complexity), validates the graph and displays it interactively with Cytoscape.js. The graph is always
generated algorithmically from the input - never hard-coded. The tool handles sequential code, if, if-else, nested conditions, while and for loops, break, continue,
multiple returns, unreachable code, empty bodies and infinite loops. It was verified with 106 automated unit/API tests and 44 real-browser checks.

## 2. Problem statement

Students usually meet control flow graphs as hand-drawn diagrams. Drawing them by hand is slow and error-prone, and it is hard to see how the algorithm
(leaders, blocks, edges) produces the picture. There is a need for a small, correct, transparent tool that builds the CFG of a program automatically,
shows the intermediate steps, and lets the user inspect nodes and edges.

## 3. Objectives

1. Parse a documented subset of C with a proper grammar and report syntax errors with line and column.
2. Convert the program into a structured IR and form basic blocks with the leader algorithm.
3. Construct a correct CFG for sequential, branching, looping and returning code, including nested control flow.
4. Compute and explain metrics: blocks, decisions, nodes, edges, reachability, loop back edges, cyclomatic complexity.
5. Present the graph interactively (inspection, zoom/pan, layouts, themes) and allow export to PNG, SVG and JSON.
6. Verify the implementation with automated tests; keep the application secure, offline-capable and easy to run on Windows.

## 4. Scope

**In scope:** a C-like subset - one `int main()` function; `int` variables; assignments (`= += -= *= /= %=`, `++`, `--`); arithmetic, relational,
equality and logical expressions; `if`, `if-else`, `while`, `for`, `break`, `continue`, `return`, nested blocks and empty statements.

**Out of scope:** the full C language, functions other than `main`, other data types, arrays, pointers, strings, `switch`, `do-while`, `goto`, semantic/type checking,
data-flow analysis and code generation (see `PROJECT_LIMITATIONS.md`). Unsupported constructs are rejected with a clear message and are never silently ignored.

## 5. Theory of Control Flow Graphs

* A **basic block** is a maximal sequence of consecutive instructions with a single entry (the first instruction) and a single exit (the last): control cannot enter in the middle or leave except at the end.
* A **CFG** is a directed graph G = (N, E): nodes are basic blocks (plus synthetic ENTRY and EXIT nodes); an edge u -> v means control may pass from u to v.
* A **decision node** ends in a conditional branch and has a *True* and a *False* successor.
* A node **dominates** another if every path from ENTRY to the latter passes through it. A **loop back edge** is an edge u -> v where v dominates u; v is the loop header.
* A block is **unreachable** if no path from ENTRY leads to it (for example code after `return`).
* **Cyclomatic complexity** (McCabe) M = E - N + 2P, where P is the number of connected components, measures the number of linearly independent paths.
  For a structured program with one entry and one exit, M equals the number of decision points plus one.

## 6. System architecture

```
 Source code
     |  (POST /api/generate-cfg)
     v
 [Flask API]  -- limits, JSON validation, error mapping
     |
     v
 +-------------------------------- cfg_engine (independent of Flask) --------------------------------+
 | parser.py + grammar.lark : pre-checks -> Lark LALR(1) -> parse tree -> AST (ast_nodes.py)          |
 | ir.py       : AST -> structured IR (stmt / branch / jump / return, labels)                         |
 | cfg.py      : leaders -> basic blocks -> edges -> jump threading                                   |
 | analysis.py : reachability, dominators, back edges, metrics, validation                            |
 | engine.py   : orchestration + JSON serialisation                                                   |
 +----------------------------------------------------------------------------------------------------+
     |  JSON {graph, metrics, warnings, analysis}
     v
 [Browser]  editor.js (line numbers)  graph.js (Cytoscape.js + dagre, PNG/SVG)  app.js (inspector, tabs, export)
```

**Technology:** Python 3.12, Flask 3.0.3, Lark 1.2.2, HTML5/CSS3/JavaScript, Cytoscape.js 3.30.2 with dagre 0.8.5 and cytoscape-dagre 2.5.0 (bundled locally, MIT licensed), Python `unittest`.
The engine is separate from the web layer, so it can be tested and reused on its own.

## 7. Methodology

The work followed the compiler front-end structure: (1) define the language subset and write the grammar; (2) build the AST; (3) design an IR that makes
control flow explicit; (4) implement the leader algorithm and CFG construction; (5) add reachability, dominators and metrics; (6) write a validator;
(7) build the API and the interactive interface; (8) write tests for each rule and fix the defects they exposed; (9) test the running application in a real browser.

### 7.1 Grammar

The grammar (`cfg_engine/grammar.lark`) is LALR(1). Operator precedence is encoded by layered rules - from lowest to highest: `||`, `&&`, `== !=`, `< <= > >=`, `+ -`, `* / %`, unary `- !`, then primary
(number, variable, parenthesised expression). Statements: declaration, assignment, increment/decrement, `if [else]`, `while`, `for`, `return`, `break`, `continue`, block, empty statement.
The dangling `else` binds to the nearest `if`.

### 7.2 Structured IR

Control statements are flattened into four instruction kinds - `stmt`, `branch(cond, L_true, L_false)`, `jump(L)` and `return` - with labels. For example `while (c) body` becomes:
`L_cond: branch c -> L_body / L_end; L_body: body; jump L_cond; L_end:`. A `for` loop adds the initialiser before `L_cond` and the update before the back jump;
`continue` jumps to the update (or to the condition of a `while`), `break` to `L_end`. An omitted `for` condition generates no branch.

## 8. Basic block algorithm (leader method)

```
Input : instruction list I[0..n-1], label positions
Output: list of basic blocks

leaders = { 0 }                                   # rule 1: first instruction
for each instruction I[i]:
    if I[i] is a jump or branch:  add the position of every target label to leaders   # rule 2
    if I[i] is a jump, branch or return and i+1 < n:  add i+1 to leaders              # rule 3
sort leaders
for each leader L_k:  block_k = I[L_k .. L_(k+1) - 1]     # up to the next leader
```

Worked example (`int i=0; int sum=0; while (i<5) { sum=sum+i; i++; } return sum;`):

| # | instruction | leader? | block |
|---|---|---|---|
| 0 | `int i = 0;` | yes (first) | B1 |
| 1 | `int sum = 0;` | | B1 |
| 2 | `if i < 5 goto 3 else goto 6` | yes (jump target of the loop-back jump) | B2 |
| 3 | `sum = sum + i;` | yes (after a branch) | B3 |
| 4 | `i++;` | | B3 |
| 5 | `goto 2` | | B3 |
| 6 | `return sum;` | yes (branch target, after a jump) | B4 |

## 9. CFG construction algorithm

```
for each block B (last instruction `last`):
    if last is branch : add edge B -> block(true target) [True],  B -> block(false target) [False]
    if last is jump   : add edge B -> block(target)
    if last is return : add edge B -> EXIT [return]            # no fall-through
    otherwise         : add edge B -> next block (or EXIT)     # fall-through
add edge ENTRY -> first block (or EXIT for an empty program)
cleanup : remove blocks that contain only a compiler-generated jump, redirecting their incoming edges (jump threading)
analysis: reachable = DFS from ENTRY; dominators by iterative data-flow;  edge u->v is a back edge iff v dominates u
```

For the example above the edges are ENTRY->B1, B1->B2, B2->B3 (True), B2->B4 (False), B3->B2 (loop back edge), B4->EXIT (return): N = 6, E = 6, M = 6 - 6 + 2 = **2** (= 1 decision + 1).

Special cases handled and tested: code after `return` is a leader with no incoming edge (unreachable); an empty `if` body sends both True and False to the same block;
an empty loop body becomes a True self-loop; `while (1)` and `for (;;)` have no exit edge, so EXIT is unreachable and flagged; literal constant conditions (`if (0)`) make the dead branch unreachable (with a warning);
nested loops keep `break`/`continue` bound to the innermost loop.

## 10. Implementation details

* **Parsing and errors:** Lark's `UnexpectedToken`/`UnexpectedCharacters` are mapped to readable messages with line and column. A missing `;` is reported at the end of the previous statement. Unsupported constructs (function calls, `float`, `switch`, arrays, `&`, ...) get specific explanations. Size, line and nesting limits protect the server.
* **Metrics:** blocks, decisions, nodes, edges, reachable/unreachable nodes, loop back edges, cyclomatic complexity E - N + 2P on the reachable sub-graph, cross-checked with decisions + 1. When EXIT is unreachable the two values differ by one and the interface says why.
* **Validator:** unique node and edge IDs; valid endpoints; valid labels; no duplicate edges; ENTRY has no predecessor and one successor; EXIT has none; every decision has exactly one True and one False edge; other blocks have one successor; return blocks go only to EXIT. Only checks that are actually run are reported.
* **API:** `POST /api/generate-cfg` (schema in `docs/API.md`), JSON errors with category, line and column, request limit 64 KB, no code execution, no CORS, debug off, localhost only, Content-Security-Policy.
* **Interface:** editor with line numbers and error/warning markers; dashboard; graph with True (green) / False (red) / back (purple dashed) edges, unreachable nodes dashed; node and edge inspector with predecessor/successor highlighting; IR & leaders tab; validation tab; light/dark theme; fullscreen; export to PNG, SVG (custom writer, escaped text) and JSON. All user text is inserted with `textContent` to prevent XSS.

## 11. Testing methodology and results

**Unit and API tests** (`python -m unittest discover -s tests -t . -v`) use small hand-verified programs and assert concrete graph properties (successor sets, labels, edge counts, complexity values), not just "does not crash".

| Test module | Focus |
|---|---|
| `test_cfg_structure.py` | sequential, if, if-else, nested, dangling else, empty branches, while, for, continue/break, nested loops, infinite loops, return, dead code, constant conditions, line numbers |
| `test_parser_errors.py` | empty/oversized input, syntax-error positions, unsupported constructs, grammar precedence, leaders |
| `test_metrics_validation.py` | complexity for 16 representative programs, E - N + 2P cross-check, node/edge invariants, validator on corrupted graphs |
| `test_api.py` | success schema, error responses, limits (415/413/400/405/404), headers, static assets |
| `test_examples.py` | every built-in example matches its documented structure |

**Result (actual run, Python 3.12.3):** 106 tests, 0 failures, 0 errors.

**Real-browser check** (`tests/ui_browser_check.py`, headless Chromium via Playwright, run against the extracted ZIP): 44 of 44 checks passed - rendering, node/edge click, highlighting, zoom/fit/layouts,
IR and validation tabs, PNG/SVG/JSON export (files opened and parsed), theme persistence, error states, XSS attempt, fullscreen, mobile layout, and no console errors.

**Not tested:** Windows itself and `run.bat` were not executed by the author of the build; this should be done once by the student before the submission.

## 12. Screenshots

Real screenshots of the running application are in `docs/screenshots/`. Insert them here when preparing the Word/PDF version:

| Figure | File | Shows |
|---|---|---|
| 1 | `docs/screenshots/01-empty-state.png` | start screen |
| 2 | `docs/screenshots/02-while-with-if-node-inspector.png` | loop with condition; node inspector; highlighted edges |
| 3 | `docs/screenshots/03-nested-if-else.png` | nested conditions |
| 4 | `docs/screenshots/05-break-continue.png` | break and continue |
| 5 | `docs/screenshots/06-unreachable-code.png` | unreachable block after return |
| 6 | `docs/screenshots/07-infinite-loop.png` | infinite loop, unreachable EXIT |
| 7 | `docs/screenshots/08-syntax-error.png` | syntax error with line and column |
| 8 | `docs/screenshots/09-ir-and-leaders.png` | IR and leaders |

![Figure 2: loop with a condition and node inspector](docs/screenshots/02-while-with-if-node-inspector.png)

[STUDENT: add one-line captions and, if you want, your own screenshots.]

## 13. Limitations

* Only an `int`-only C subset with one `main` function; no semantic analysis (undeclared variables, types, scopes are not checked).
* `&&` and `||` are not expanded into separate decisions (short-circuit control flow is not modelled); each condition counts once.
* Only integer-literal conditions are constant-folded.
* Compiler-generated jump-only blocks are removed (documented jump threading), so block counts follow this convention.
* No data-flow analysis or optimisation; Flask development server only; very large graphs need zooming.

## 14. Future scope

Short-circuit expansion of `&&`/`||`; `switch` and `do-while`; several functions with a call graph; reaching-definitions and live-variable analysis on the CFG;
dominator tree and loop nesting view; DOT/Graphviz export; step-by-step trace of a safe interpreter; support for more C types.

## 15. Conclusion

CFG Studio shows the complete path from source text to a control flow graph using real compiler techniques - a grammar-based parser, an AST, a structured IR, the leader algorithm, dominator-based loop detection and
a verified metric - together with a usable interface for exploring the result. It handles the control-flow cases that most often cause mistakes (return termination, nested loops with break/continue, empty bodies, infinite loops) and
is covered by automated tests. It meets the aim of making CFG construction visible and understandable for students.

## 16. References

*Check each reference yourself before submitting - these were written from memory without access to a library or database, and details may be inaccurate.*

1. A. V. Aho, M. S. Lam, R. Sethi, J. D. Ullman, *Compilers: Principles, Techniques, and Tools* (2nd ed.), Addison-Wesley, 2006 - basic blocks, flow graphs, leaders.
2. K. D. Cooper, L. Torczon, *Engineering a Compiler* (2nd ed.), Morgan Kaufmann, 2011 - control-flow analysis, dominators.
3. T. J. McCabe, "A Complexity Measure", *IEEE Transactions on Software Engineering*, SE-2(4), 1976 - cyclomatic complexity.
4. F. E. Allen, "Control Flow Analysis", *ACM SIGPLAN Notices* 5(7), 1970.
5. Lark parsing toolkit documentation - https://lark-parser.readthedocs.io
6. Cytoscape.js - https://js.cytoscape.org ; dagre - https://github.com/dagrejs/dagre
7. Flask documentation - https://flask.palletsprojects.com

## 17. Declaration (to be completed by the student)

[STUDENT: add the declaration / acknowledgement text required by the department, signature and date.]
